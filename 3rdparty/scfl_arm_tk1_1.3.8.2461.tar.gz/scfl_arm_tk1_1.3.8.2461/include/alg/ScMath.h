#ifndef SCMATH_H
#define SCMATH_H
//#include "SCDef.h"
#include "ScType.h"

/** @file ScMath.h
* @brief ��ѧ����
*/

#define round(val) ((int)(val+0.5f))

#define PI 3.1415926
#define PI_2 1.5707963

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#  ifdef __cplusplus
extern "C" {
#  endif /* __cplusplus */

// ͳһʹ��SCAPIһ��һ����ָ�������������һ�£����ڵ�����

SCFL_API void scVecSub6(short *restrict subs, const short *restrict in1, const short *restrict	in2, unsigned int N);
	//fast dot product
SCFL_API int scDotProd(const short *restrict a, const short *restrict b, unsigned int N);

SCFL_API int scDotProdCharShort(const char *restrict a, const short *restrict b, unsigned int N);

SCFL_API int scDotProdChar(const unsigned char *restrict a, const char *restrict b, unsigned int N);

	//vecter substract
SCFL_API void scVecSub4(short *restrict subs, const short *restrict in1, const short *restrict in2, unsigned int N);
	//vecter addition N must be multiple of 4
SCFL_API void scVecAdd6(short *restrict sums, short *restrict in1, const short *restrict in2, unsigned int N);

SCFL_API void scVecAdd6Char(short *restrict sums, unsigned char *restrict in1, unsigned char *restrict in2, unsigned int N);

SCFL_API int scIntExp(int input1);
	//fix-point function to compute exp: input and output are all Q11 
	#define num11 2048 //2^11

SCFL_API int scSqt2(int in1);

SCFL_API int scMathSin(int angle);// 360 is 4096
SCFL_API int scMathCos(int angle);// 360 is 4096
SCFL_API int scMathAtan(int angle);//input is real<<7, return is degree 90<-->1024

SCFL_API short GetHorizonCenter(const short* pfSample, short nWidth, short nHeight, short nStride);

#if WIN32
#define _abs(x) ((x)>0?(x):-(x))
#endif

SCFL_API int DSP_vecsumsq(short* data, int length);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
