#ifndef SC_VDO_SET_H
#define SC_VDO_SET_H

#include "ScVdoDef.h"
#include "ScType.h"

/** @file IVdoSet.h
* @brief VDO���ݼ��ӿ�
*/


/** @class IVdoSet
* @brief ���ݼ�����ӿ�
*/
class IVdoSet
{
public:
	IVdoSet(void){};
	virtual ~IVdoSet(void){};
public:
	virtual void Init(HVDOCon hVdoCon,const char* szTableName) = 0;
	virtual void UnInit() = 0;

	virtual void InitStoreProc(HVDOCon hVdoCon,const char* szStoreProcName) = 0;	
	virtual void UnInitStoreProc() = 0;
public:
	virtual void GetTableName(char* pszTableName)=0;

public:	// ��ѯ
	virtual int Query(const char* szCondition, const char* szOrderby="")=0;	// szCondition: where �����沿��
	virtual bool MoveNext()=0;
	virtual int GetRecordCount()=0;	// returns: ��ǰ��¼���а�������
	virtual bool IsReachEnd() = 0;

	virtual int GetColumCount()=0;	// �����еĸ���
	virtual bool GetColumName(long lIndex, char szBuffer[], int nBufSize) = 0;
	virtual bool GetColumInfo(long lIndex, char szBuffer[], int nBufSize, VT_EDbDataType& columnType) = 0;
	//////////////////////////////////////////////////////////////////////////
public:	// ����ǰ��¼��һ��	// lIndex: base on 0
	virtual bool	GetBool(long lIndex)=0;
	virtual char	GetByte(long lIndex)=0;
	virtual short	GetInt16(long lIndex)=0;
	virtual int		GetInt32(long lIndex)=0;
	virtual float	GetFloat(long lIndex)=0;
	virtual double	GetDouble(long lIndex)=0;
	virtual void	GetString(long lIndex, char szBuffer[], int nBufSize)=0;
	virtual int		GetByteCount(long lIndex)=0;					// �����������ݣ�ͼ��ʱ��
	virtual void	GetBinary(long lIndex, char* szBuffer)=0;	// �����������ݣ�ͼ��ʱ��
	virtual ScSystemTime GetTime(long lIndex)=0;
	virtual bool	GetIsNull(long lIndex)=0;

	//////////////////////////////////////////////////////////////////////////
public:	// ����ǰ��¼��һ��	// szCN: base on 0
	virtual bool	GetBool(const char* szCN)=0;
	virtual char	GetByte(const char* szCN)=0;
	virtual short	GetInt16(const char* szCN)=0;
	virtual int		GetInt32(const char* szCN)=0;
	virtual float	GetFloat(const char* szCN)=0;
	virtual double	GetDouble(const char* szCN)=0;
	virtual void	GetString(const char* szCN, char szBuffer[], int nBufSize)=0;
	virtual int		GetByteCount(const char* szCN)=0;					// �����������ݣ�ͼ��ʱ��
	virtual void	GetBinary(const char* szCN, char* szBuffer)=0;	// �����������ݣ�ͼ��ʱ��
	virtual ScSystemTime GetTime(const char* szCN)=0;
	virtual bool	GetIsNull(const char* szCN)=0;

	//////////////////////////////////////////////////////////////////////////
public:	// ׼����Insert�� ��Update��
	virtual void	PutBool(long lIndex, bool bValue)=0;
	virtual void	PutByte(long lIndex, char uchValue)=0;
	virtual void	PutInt16(long lIndex, short n16Value)=0;
	virtual void	PutInt32(long lIndex, int n32Value)=0;
	virtual void	PutFloat(long lIndex, float fValue)=0;
	virtual void	PutDouble(long lIndex, double dValue)=0;
	virtual void	PutString(long lIndex, const char* szValue)=0;
	virtual void	PutBinary(long lIndex, const char* szBuffer, int nBufLength)=0;
	virtual void	PutTime(long lIndex, ScSystemTime stTime)=0;

	//////////////////////////////////////////////////////////////////////////
public:	// ׼����Insert�� ��Update��
	virtual void	PutBool(const char* szCN, bool bValue)=0;
	virtual void	PutByte(const char* szCN, char uchValue)=0;
	virtual void	PutInt16(const char* szCN, short n16Value)=0;
	virtual void	PutInt32(const char* szCN, int n32Value)=0;
	virtual void	PutFloat(const char* szCN, float fValue)=0;
	virtual void	PutDouble(const char* szCN, double dValue)=0;
	virtual void	PutString(const char* szCN, const char* szValue)=0;
	virtual void	PutBinary(const char* szCN, const char* szBuffer, int nBufLength)=0;
	virtual void	PutTime(const char* szCN, ScSystemTime stTime)=0;

public:
	virtual bool	PutBoolParam(const char* szCN, ScParamDirectEnum Direction, long Size, bool Value)=0;
	virtual bool	PutByteParam(const char* szCN,  ScParamDirectEnum Direction, long Size, char Value)=0;
	virtual bool	PutInt16Param(const char* szCN,  ScParamDirectEnum Direction, long Size, short Value)=0;
	virtual bool	PutInt32Param(const char* szCN,  ScParamDirectEnum Direction, long Size, int Value)=0;
	virtual bool	PutFloatParam(const char* szCN,  ScParamDirectEnum Direction, long Size, float Value)=0;
	virtual bool	PutDoubleParam(const char* szCN, ScParamDirectEnum Direction, long Size, double Value)=0;
	virtual bool	PutStringParam(const char* szCN, ScParamDirectEnum Direction, long Size, 
		const char* Value)=0;
	virtual bool	PutBinaryParam(const char* szCN, ScParamDirectEnum Direction, long Size, 
		const char* szBuffer)=0;
	virtual bool	PutTimeParam(const char* szCN, ScParamDirectEnum Direction, long Size, ScSystemTime stTime)=0;

	virtual bool	GetBoolParam(const char* szCN)=0;
	virtual char	GetByteParam(const char* szCN)=0;
	virtual short	GetInt16Param(const char* szCN)=0;
	virtual int		GetInt32Param(const char* szCN)=0;
	virtual float	GetFloatParam(const char* szCN)=0;
	virtual double	GetDoubleParam(const char* szCN)=0;
	virtual void	GetStringParam(const char* szCN, char szBuffer[], int nBufSize)=0;
	virtual int		GetByteCountParam(const char* szCN)=0;				// �����������ݣ�ͼ��ʱ��
	virtual void	GetBinaryParam(const char* szCN, char* szBuffer)=0;	// �����������ݣ�ͼ��ʱ��
	virtual ScSystemTime GetTimeParam(const char* szCN)=0;
	virtual bool	GetIsNullParam(const char* szCN)=0;
	//////////////////////////////////////////////////////////////////////////

public:	// ����
	virtual void AddNewBegin()=0;
	// PutValue(), ..., PutValue()
	virtual void AddNewEnd()=0;

public:	// ����
	virtual bool UpdateBySQL(const char* szContent)=0;	// szContent: set �����沿��

public:	// ɾ��
	virtual int Delete(const char* szCondition)=0;	// szCondition: sql��䣬 ����ֵ��ִ���Ƿ�ɹ�

public:	
	virtual void OpenRW(const char* szSQL)=0;// �򿪽����

public://ִ��SQL��䲻���ؽ��
	virtual bool ExecuteSQL(const char* szSQL)=0;
	virtual bool ExecuteStoreProc()=0;

public:	// ��ѯ�������
	virtual bool IsError() = 0;
	virtual void GetLastError(OUT int &nCode, OUT char *szDiscBuf, IN int nBufSize) = 0;

	// ȡ�����һ���û�ִ�е�SQL���
	virtual const char* GetLastSQL() = 0;
};

#endif
