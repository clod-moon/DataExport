#ifndef SC_VDO_CONNECTION_H
#define SC_VDO_CONNECTION_H

#include "ScVdoDef.h"

/** @file IVdoConnection.h
* @brief VDO���ӽӿ�
*/

#define VdoStorage_Database			0x0001
#define VdoStorage_XML				0x0002

/** @class IVdoConnection
* @brief ���ӳ���ӿ�
*/
class IVdoConnection
{
public:
	virtual bool OpenVdoConnection(int databaseType,const char* serverName,const char* databaseName,const char* userName,const char* userPass) = 0;
	virtual bool OpenVdoConnectionEx(int databaseType,const char* cszConnText) = 0;
	virtual void CloseVdoConnection() = 0;
public:
	virtual bool ExecSQL(const char* szSQL) = 0;
	virtual const char* GetLastSQL() = 0;
public:
	virtual void BeginTrans() = 0;
	virtual void CommitTrans() = 0;
	virtual void RollbackTrans() = 0;
public:
	virtual void GetLastError(int &nCode, char *szDiscBuf, int nBufSize) = 0;
public:
	IVdoConnection(void){}
	virtual ~IVdoConnection(void){}
public:
	int m_nDataBaseType;//���ݿ�����
};


#endif