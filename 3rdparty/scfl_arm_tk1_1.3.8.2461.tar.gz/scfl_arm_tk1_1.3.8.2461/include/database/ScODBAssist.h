#ifndef CSC_ODB_ASSIST_H
#define CSC_ODB_ASSIST_H

/** @file ScODBAssist.h
* @brief �������ṹ�����ݿ�ӿ�
*/

#include "IVdoManager.h"
#include "ScStmtPrepareInsertAddUpdate.h"
#include "IDataContainer.h"


/** @class CScODBAssist
* @brief �������ṹ�����ݿ�����ӿ�
*/
class SCFL_API CScODBAssist
{
public:
	CScODBAssist();
	~CScODBAssist();

	ScErr Insert(const char* szTableName, IDataContainer** pInsertContainer, unsigned int recordCount);
	ScErr Insert(const char* szTableName, IDataContainer* pInsertContainer);
	ScErr Query(const char* szSqlCmd/*, IDataContainer* pResultContainer*/);
	ScErr Query(const char* szTableName, const char* szCondition/*, IDataContainer* pResultContainer*/,  const char* szOrderby = NULL);
	ScErr GetNext(IDataContainer*);
	ScErr Update(const char* szTableName,const char* szCondition, IDataContainer* pUpdateContainer);
	int GetRecordCount();
	ScErr Delete(const char* szTableName, const char* szCondition);
	void Init(IVdoManager *p, HVDOCon vdoConn=NULL, int nDbType = 2);
private:
	string MakeDateStr(ScSystemTime tItemValue);
	ScErr QueryHelper(IDataContainer* pOutParam);
private:
	IVdoManager* m_VdoMan;
	HVDOCon m_VdoConn;
	int m_DbType;
	int m_recordCount;
	CVdoRW *m_pTable;
};


#endif
