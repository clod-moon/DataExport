#ifndef SHARED_PTR_ARR_H
#define SHARED_PTR_ARR_H

#include "assert.h"
#include <iostream>
using namespace std;

template<class T> inline void checkd_delete_array(T * x)
{
	// intentionally complex - simplification causes regressions
	typedef char type_must_be_complete[ sizeof(T)? 1: -1 ];
	(void) sizeof(type_must_be_complete);
	delete [] x;
}

template<class T> class shared_array
{
private:

	typedef long count_type;

public:

	typedef T element_type;
	typedef T value_type;

	explicit shared_array(T * p = 0): px(p)
	{
		try  // prevent leak if new throws
		{
			pn = new count_type(1);
		}
		catch(...)
		{
			checkd_delete_array(p);
			throw;
		}
	}

	~shared_array()
	{
		if(--*pn == 0)
		{
			checkd_delete_array(px);
			delete pn;
		}
	}

	shared_array(shared_array const & r): px(r.px)  // never throws
	{
		pn = r.pn;
		++*pn;
	}

	shared_array & operator=(shared_array const & r)
	{
		// shared_array(r).swap(*this);
		if(this == &r) return *this;
		if(--*pn == 0)
		{
			checkd_delete_array(px);
			delete pn;
		}
		px = r.px;
		++(*r.pn);
		pn = r.pn;
		return *this;
	}

	void reset(T * p = 0)
	{
		assert(p == 0 || p != px);
		shared_array(p).swap(*this);
	}

	T & operator*() const  // never throws
	{
		assert(px != 0);
		return *px;
	}

	T * operator->() const  // never throws
	{
		assert(px != 0);
		return px;
	}

	T * get() const  // never throws
	{
		return px;
	}

	long use_count() const  // never throws
	{
		return *pn;
	}

	bool unique() const  // never throws
	{
		return *pn == 1;
	}

	void swap(shared_array<T> & other)  // never throws
	{
		std::swap(px, other.px);
		std::swap(pn, other.pn);
	}

private:

	T * px;            // contained pointer
	count_type * pn;   // ptr to reference counter
};

#endif
	
