#ifndef I_CONTAINER_H
#define I_CONTAINER_H

#include <string>
#include <string.h>
#include "ScErr.h"
#include "ScTimeUtils.h"
#include "ScBaseStruct.h"
#include "IContainerBase.h"
#include "assert.h"
#include "ScVariant.h"
using namespace std;

#define DC_MEMINFO_NAME_LEN 64

typedef struct _DCMemInfo
{   
	char  sMemName[DC_MEMINFO_NAME_LEN];	
	DCMemType   nType;	
	unsigned int nLen;
	unsigned int nIndex;

	_DCMemInfo()
	{
		memset(sMemName, 0, sizeof(sMemName));
		nType = DC_ERR;
		nLen = 0;
		nIndex = 0;
	}

	_DCMemInfo(const char* szName)
	{
		assert(szName != NULL);
		memcpy(sMemName, szName, sizeof(sMemName));
		nType = DC_ERR;
		nLen = 0;
		nIndex = 0;
	}

	_DCMemInfo(const char* szName, DCMemType Type, unsigned int Len, unsigned int Index)
	{
		assert(szName != NULL);
		memcpy(sMemName, szName, sizeof(sMemName));
		nType = Type;
		nLen = Len;
		nIndex = Index;
	}

	operator int() const
	{
		unsigned int uIndex = nIndex;
		return uIndex;
	}

	operator const char*() const
	{
		return sMemName;
	}

	bool operator < ( const _DCMemInfo& other) const
	{		
		//string thisName = smemName;
		//string otherName = other.sMemName;
		//transform(thisName.begin(),thisName.end(),thisName.begin(), toupper);	
		//transform(otherName.begin(),otherName.end(),otherName.begin(), toupper);	
#ifndef LINUX
		return (stricmp(sMemName, other.sMemName) < 0);
#else
		return (strcasecmp(sMemName, other.sMemName) < 0);
#endif
	}
}DCMemInfo;    

class SCFL_API IDataContainer
	:public IScRunTimeStruct
{
public:
	IDataContainer(void){}
	virtual ~IDataContainer(void) {};
	/*��ȡ��Ա����������һ�����ڱ���*/
	virtual unsigned int GetMemberCount() = 0;
	/*��ȡ��Ա��������Ϣ����ͨ���������������ƶ��������ڲ�ʹ�ñ�����ȡ*/
	virtual ScErr GetMemberInfo(unsigned int nIndex,DCMemInfo& meminfo)=0;
	virtual ScErr GetMemberInfo(const char* szName,DCMemInfo& meminfo)=0;
	virtual ScErr DestoryMember(unsigned int nIndex)=0;
	virtual ScErr DestoryMember(const char* szName)=0;
	/*��ȡ/���ó�Ա����ֵ��ͨ��������������*/
	virtual ScErr SetMember(const char* szName,int nValue)=0;
	virtual ScErr GetMember(const char* szName,int& nValue)=0;
	virtual ScErr SetMember(const char* szName,float nValue)=0;
	virtual ScErr GetMember(const char* szName,float& nValue)=0;
	virtual ScErr SetMember(const char* szName,string nValue)=0;
	virtual ScErr GetMember(const char* szName,string& nValue)=0;
	virtual ScErr SetMember(const char* szName,char* nValue, unsigned int uSize )=0;
	virtual ScErr GetMember(const char* szName,char*& nValue, unsigned int& uSize )=0;
	virtual ScErr SetMember(const char* szName,ScSystemTime nValue)=0;
	virtual ScErr GetMember(const char* szName,ScSystemTime& nValue)=0;
	virtual ScErr SetMember(const char* szName,bool nValue)=0;
	virtual ScErr GetMember(const char* szName,bool& nValue)=0;
	virtual ScErr SetMember(const char* szName,ScVariant nValue)=0;
	virtual ScErr GetMember(const char* szName,ScVariant& nValue)=0;

	virtual ScErr SetMember(unsigned int nIndex,int nValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,int& nValue)=0;
	virtual ScErr SetMember(unsigned int nIndex,float nValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,float& nValue)=0;
	virtual ScErr SetMember(unsigned int nIndex,string nValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,string& nValue)=0;
	virtual ScErr SetMember(unsigned int nIndex,char* nValue, unsigned int uSize )=0;
	virtual ScErr GetMember(unsigned int nIndex,char*& nValue, unsigned int& uSize )=0;
	virtual ScErr SetMember(unsigned int nIndex,ScSystemTime nValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,ScSystemTime& nValue)=0;
	virtual ScErr SetMember(unsigned int nIndex,bool nValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,bool& nValue)=0;
	virtual ScErr SetMember(unsigned int nIndex,ScVariant nValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,ScVariant& nValue)=0;

	virtual ScErr SetMember(const char* szName, IDataContainer* pValue)=0;
	virtual ScErr SetMember(unsigned int nIndex, IDataContainer* pValue)=0;

	virtual ScErr GetMember(const char* szName,IDataContainer* &pValue)=0;
	virtual ScErr GetMember(unsigned int nIndex,IDataContainer* &pValue)=0;

	virtual ScErr SetMember(const char* szName, IDataContainer** pValue, unsigned int uSize )=0;
	virtual ScErr SetMember(unsigned int nIndex, IDataContainer** pValue, unsigned int uSize )=0;

	virtual ScErr GetMember(const char* szName,IDataContainer** &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(unsigned int nIndex,IDataContainer** &pValue , unsigned int& uSize )=0;

	virtual ScErr SetMember(const char* szName,int* pValue , unsigned int uSize )=0;
	virtual ScErr SetMember(const char* szName,float* pValue , unsigned int uSize )=0;
	virtual ScErr SetMember(const char* szName,ScSystemTime* pValue , unsigned int uSize )=0;
	virtual ScErr SetMember(const char* szName,bool* pValue , unsigned int uSize )=0;

	virtual ScErr GetMember(const char* szName,int* &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(const char* szName,float* &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(const char* szName,ScSystemTime* &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(const char* szName,bool* &pValue , unsigned int& uSize )=0;

	virtual ScErr SetMember(unsigned int nIndex,int* pValue , unsigned int uSize )=0;
	virtual ScErr SetMember(unsigned int nIndex,float* pValue , unsigned int uSize )=0;
	virtual ScErr SetMember(unsigned int nIndex,ScSystemTime* pValue , unsigned int uSize )=0;
	virtual ScErr SetMember(unsigned int nIndex,bool* pValue , unsigned int uSize )=0;

	virtual ScErr GetMember(unsigned int nIndex,int* &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(unsigned int nIndex,float* &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(unsigned int nIndex,ScSystemTime* &pValue , unsigned int& uSize )=0;
	virtual ScErr GetMember(unsigned int nIndex,bool* &pValue , unsigned int& uSize )=0;

	/*����������������������֮�俽����Ĭ�Ͽ���������ɽӿڼ俽��*/
	virtual ScErr Copy(IDataContainer*)=0;
	/*���ڳ־û�����������ʵ�ַ��־û�����������û������*/
	virtual const char* RTSName()=0;	//����
	virtual const char* Name()=0;	//��������
};


#endif
