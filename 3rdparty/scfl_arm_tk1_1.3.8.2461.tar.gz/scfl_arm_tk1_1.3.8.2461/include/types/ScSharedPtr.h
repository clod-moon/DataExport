#ifndef SHARED_PTR_H
#define SHARED_PTR_H

#include "assert.h"
#include <iostream>
using namespace std;

template<class T> inline void checked_delete(T * x)
{
	// intentionally complex - simplification causes regressions
	typedef char type_must_be_complete[ sizeof(T)? 1: -1 ];
	(void) sizeof(type_must_be_complete);
	delete x;
}

template<class T> class shared_ptr
{
private:

	typedef long count_type;

public:

	typedef T element_type;
	typedef T value_type;

	explicit shared_ptr(T * p = 0): px(p)
	{
		try  // prevent leak if new throws
		{
			pn = new count_type(1);
		}
		catch(...)
		{
			checked_delete(p);
			throw;
		}
	}

	~shared_ptr()
	{
		if(--*pn == 0)
		{
			checked_delete(px);
			delete pn;
		}
	}

	shared_ptr(shared_ptr const & r): px(r.px)  // never throws
	{
		pn = r.pn;
		++*pn;
	}

	shared_ptr & operator=(shared_ptr const & r)
	{
		if(this == &r) return *this;
		if(--*pn == 0)
		{
			checked_delete(px);
			delete pn;
		}
		px = r.px;
		++(*r.pn);
		pn = r.pn;
		return *this;
	}

	void reset(T * p = 0)
	{
		assert(p == 0 || p != px);
		shared_ptr(p).swap(*this);
	}

	T & operator*() const  // never throws
	{
		assert(px != 0);
		return *px;
	}

	T * operator->() const  // never throws
	{
		assert(px != 0);
		return px;
	}

	bool operator==( int n)
	{
		if( px == (T*)n)
			return true;

		return false;
	}
	
	bool operator!=( int n)
	{
		if( px == (T*)n)
			return false;

		return true;
	}
	T * get() const  // never throws
	{
		return px;
	}

	long use_count() const  // never throws
	{
		return *pn;
	}

	bool unique() const  // never throws
	{
		return *pn == 1;
	}

	void swap(shared_ptr<T> & other)  // never throws
	{
		std::swap(px, other.px);
		std::swap(pn, other.pn);
	}

private:

	T * px;            // contained pointer
	count_type * pn;   // ptr to reference counter
};

#endif
	
