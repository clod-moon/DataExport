#pragma once
#include "IDataContainer.h"

#include <map>
#include <string>
using namespace std;

/*��ȡ/���ñ���ֵͨ�ú�������*/
typedef void ( IDataContainer::*GetMemP)(void* &p);
typedef void ( IDataContainer::*SetMemP)(void*);

typedef struct _SDSMemInfoEx
{   
	DCMemInfo nInfo;
	GetMemP nGetMemP;
	SetMemP nSetMemP;
}SDSMemInfoEx;

typedef SDSMemInfoEx MSG_ARRAY_ENTRY;       

struct MSG_ARRAY
{
	const MSG_ARRAY* pBaseArray;
	const MSG_ARRAY_ENTRY* lpEntries;
};

#define DECLARE_SDS _DECLARE_SDS

#define MEMBER_ASSIGN_INT _MEMBER_ASSIGN_INT
#define MEMBER_ASSIGN_FLOAT _MEMBER_ASSIGN_FLOAT
#define MEMBER_ASSIGN_STRING _MEMBER_ASSIGN_STRING
#define MEMBER_ASSIGN_CHARARR _MEMBER_ASSIGN_CHARARR
#define MEMBER_ASSIGN_TIME _MEMBER_ASSIGN_TIME
#define MEMBER_ASSIGN_BOOL _MEMBER_ASSIGN_BOOL
#define MEMBER_ASSIGN_SDS _MEMBER_ASSIGN_SDS
#define MEMBER_ASSIGN_ARRAY_INT _MEMBER_ASSIGN_ARRAY_INT
#define MEMBER_ASSIGN_ARRAY_FLOAT _MEMBER_ASSIGN_ARRAY_FLOAT
#define MEMBER_ASSIGN_ARRAY_TIME _MEMBER_ASSIGN_ARRAY_TIME
#define MEMBER_ASSIGN_ARRAY_BOOL _MEMBER_ASSIGN_ARRAY_BOOL
#define MEMBER_ASSIGN_ARRAY_SDS _MEMBER_ASSIGN_ARRAY_SDS
#define MEMBER_ASSIGN_VAR _MEMBER_ASSIGN_VAR

#define BEGIN_MEMBER_ARRAY _BEGIN_MEMBER_ARRAY
#define END_MEMBER_ARRAY _END_MEMBER_ARRAY

#define MEM_DEFINE_INT _MEM_DEFINE_INT
#define MEM_DEFINE_FLOAT _MEM_DEFINE_FLOAT
#define MEM_DEFINE_STRING _MEM_DEFINE_STRING
#define MEM_DEFINE_CHARARR _MEM_DEFINE_CHARARR
#define MEM_DEFINE_TIME _MEM_DEFINE_TIME
#define MEM_DEFINE_BOOL _MEM_DEFINE_BOOL
#define MEM_DEFINE_SDS _MEM_DEFINE_SDS
#define MEM_DEFINE_ARRAY_INT _MEM_DEFINE_ARRAY_INT
#define MEM_DEFINE_ARRAY_FLOAT _MEM_DEFINE_ARRAY_FLOAT
#define MEM_DEFINE_ARRAY_TIME _MEM_DEFINE_ARRAY_TIME
#define MEM_DEFINE_ARRAY_BOOL _MEM_DEFINE_ARRAY_BOOL
#define MEM_DEFINE_ARRAY_SDS _MEM_DEFINE_ARRAY_SDS
#define MEM_DEFINE_VAR _MEM_DEFINE_VAR

class CScSelfDescribStructImpl :
	public IDataContainer
{
public:	
	CScSelfDescribStructImpl(void);
	virtual ~CScSelfDescribStructImpl(void);

public:
	ScErr GetMemberInfo(unsigned int nIndex,DCMemInfo& meminfo);
	ScErr GetMemberInfo(const char* szName,DCMemInfo& meminfo);
	////////////////////////////////////////////
	//guochao add 20140826 ����IDataContainer�е�DestoryMember�ӿ�
	ScErr DestoryMember(unsigned int nIndex);
	ScErr DestoryMember(const char* szName);
	////////////////////////////////////////////
	ScErr SetMember(const char* szName,void* nValue);
	ScErr GetMember(const char* szName,void* &nValue);
	ScErr SetMember(const char* szName,int nValue);
	ScErr GetMember(const char* szName,int& nValue);
	ScErr SetMember(const char* szName,float nValue);
	ScErr GetMember(const char* szName,float& nValue);	
	ScErr SetMember(const char* szName,string nValue);
	ScErr GetMember(const char* szName,string& nValue);
	ScErr SetMember(const char* szName,char* nValue, unsigned int uSize);
	ScErr GetMember(const char* szName,char*& nValue, unsigned int& uSize);
	ScErr SetMember(const char* szName,ScSystemTime nValue);
	ScErr GetMember(const char* szName,ScSystemTime& nValue);
	ScErr SetMember(const char* szName,bool nValue);
	ScErr GetMember(const char* szName,bool& nValue);
	ScErr SetMember(const char* szName,ScVariant nValue);
	ScErr GetMember(const char* szName,ScVariant& nValue);

	ScErr SetMember(unsigned int nIndex,void* nValue);
	ScErr GetMember(unsigned int nIndex,void* &nValue);
	ScErr SetMember(unsigned int nIndex,int nValue);
	ScErr GetMember(unsigned int nIndex,int& nValue);
	ScErr SetMember(unsigned int nIndex,float nValue);
	ScErr GetMember(unsigned int nIndex,float& nValue);
	ScErr SetMember(unsigned int nIndex,string nValue);
	ScErr GetMember(unsigned int nIndex,string& nValue);
	ScErr SetMember(unsigned int nIndex,char* nValue, unsigned int uSize);
	ScErr GetMember(unsigned int nIndex,char*& nValue, unsigned int& uSize);
	ScErr SetMember(unsigned int nIndex,ScSystemTime nValue);
	ScErr GetMember(unsigned int nIndex,ScSystemTime& nValue);
	ScErr SetMember(unsigned int nIndex,bool nValue);
	ScErr GetMember(unsigned int nIndex,bool& nValue);
	ScErr SetMember(unsigned int nIndex,ScVariant nValue);
	ScErr GetMember(unsigned int nIndex,ScVariant& nValue);

	ScErr SetMember(const char* szName, IDataContainer* pValue);
	ScErr SetMember(unsigned int nIndex, IDataContainer* pValue);

	ScErr GetMember(const char* szName,IDataContainer* &pValue);
	ScErr GetMember(unsigned int nIndex,IDataContainer* &pValue);

	ScErr SetMember(const char* szName, IDataContainer** pValue, unsigned int uSize);
	ScErr SetMember(unsigned int nIndex, IDataContainer** pValue, unsigned int uSize);

	ScErr GetMember(const char* szName,IDataContainer** &pValue , unsigned int& uSize);
	ScErr GetMember(unsigned int nIndex,IDataContainer** &pValue , unsigned int& uSize);

	ScErr SetMember(const char* szName,int* pValue , unsigned int uSize);
	ScErr SetMember(const char* szName,float* pValue , unsigned int uSize);
	ScErr SetMember(const char* szName,ScSystemTime* pValue , unsigned int uSize);
	ScErr SetMember(const char* szName,bool* pValue , unsigned int uSize);

	ScErr GetMember(const char* szName,int* &pValue , unsigned int& uSize);
	ScErr GetMember(const char* szName,float* &pValue , unsigned int& uSize);
	ScErr GetMember(const char* szName,ScSystemTime* &pValue , unsigned int& uSize);
	ScErr GetMember(const char* szName,bool* &pValue , unsigned int& uSize);

	ScErr SetMember(unsigned int nIndex,int* pValue , unsigned int uSize);
	ScErr SetMember(unsigned int nIndex,float* pValue , unsigned int uSize);
	ScErr SetMember(unsigned int nIndex,ScSystemTime* pValue , unsigned int uSize);
	ScErr SetMember(unsigned int nIndex,bool* pValue , unsigned int uSize);

	ScErr GetMember(unsigned int nIndex,int* &pValue , unsigned int& uSize);
	ScErr GetMember(unsigned int nIndex,float* &pValue , unsigned int& uSize);
	ScErr GetMember(unsigned int nIndex,ScSystemTime* &pValue , unsigned int& uSize);
	ScErr GetMember(unsigned int nIndex,bool* &pValue , unsigned int& uSize);

	unsigned int GetMemberCount();
	ScErr GetMemberSize(const char* szName, unsigned int& len);
	ScErr GetMemberSize(unsigned int nIndex, unsigned int& len);
	virtual const MSG_ARRAY* GetMemberArr() const = 0;
	ScErr Copy(IDataContainer* pStructImpl);
	virtual const char* RTSName()=0;
	const char* Name(){return "SDS";}
};

#define _DECLARE_SDS(theClass) \
public: \
	const char* RTSName() \
	{return #theClass;} \
private: \
	static const MSG_ARRAY_ENTRY _memberEntries[]; \
protected: \
	static const MSG_ARRAY memberArray; \
	virtual const MSG_ARRAY* GetMemberArr() const; \

#define _MEMBER_ASSIGN_INT(NAME) \
{ DCMemInfo(#NAME, DC_INT, 1,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_FLOAT(NAME) \
{DCMemInfo(#NAME, DC_FLOAT, sizeof(float),0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_STRING(NAME) \
{DCMemInfo(#NAME, DC_STRING, 0,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_CHARARR(NAME, LEN) \
{DCMemInfo(#NAME, DC_CHARARR, LEN,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_TIME(NAME) \
{DCMemInfo(#NAME, DC_TIME, sizeof(ScSystemTime),0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_BOOL(NAME) \
{DCMemInfo(#NAME, DC_BOOL, sizeof(bool),0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_SDS(SDSNAME,NAME) \
{DCMemInfo(#NAME, DC_DC, 1,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_ARRAY_INT(NAME, LEN) \
{DCMemInfo(#NAME, DC_INT|DC_ARRAY, LEN,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_ARRAY_FLOAT(NAME, LEN) \
{DCMemInfo(#NAME, DC_FLOAT|DC_ARRAY, LEN,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_ARRAY_TIME(NAME, LEN) \
{DCMemInfo(#NAME, DC_TIME|DC_ARRAY, LEN,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_ARRAY_BOOL(NAME, LEN) \
{DCMemInfo(#NAME, DC_BOOL|DC_ARRAY, LEN,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_ARRAY_SDS(NAME, LEN) \
{DCMemInfo(#NAME, DC_DC|DC_ARRAY, LEN,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},
#define _MEMBER_ASSIGN_VAR(NAME) \
{DCMemInfo(#NAME, DC_VAR, 1,0), static_cast<GetMemP>(&_theClass::_Get##NAME), static_cast<SetMemP>(&_theClass::_Set##NAME)},

#define _BEGIN_MEMBER_ARRAY(theClass/*, baseClass*/) \
REG_RUNTIME_STRUCT(theClass) \
typedef theClass _theClass; \
const MSG_ARRAY* theClass::GetMemberArr() const \
{ return &theClass::memberArray; } \
const MSG_ARRAY theClass::memberArray = \
{ /*&baseClass*/&theClass::memberArray, &theClass::_memberEntries[0] }; \
const MSG_ARRAY_ENTRY theClass::_memberEntries[] = \
{ \

#define _END_MEMBER_ARRAY(NAME) \
{DCMemInfo("", DC_END, 0,0), NULL, NULL}, \
}; \

#define _MEM_DEFINE_INT(MEMNAME)\
public:\
	int MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){*(int*)nMemName = MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME = *(int*)nMemName;}\

#define _MEM_DEFINE_FLOAT(MEMNAME)\
public:\
	float MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){*(float*)nMemName = MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME = *(float*)nMemName;}\

#define _MEM_DEFINE_STRING(MEMNAME)\
public:\
	string MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){*static_cast<string*>(nMemName) = MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME = *static_cast<string*>(nMemName);}\

#define _MEM_DEFINE_CHARARR(MEMNAME, LEN)\
public:\
	char MEMNAME[LEN];\
public:\
	void _Get##MEMNAME(void* &nMemName){nMemName = (void*)MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){strncpy(MEMNAME, (char *)nMemName, LEN);}\

#define _MEM_DEFINE_TIME(MEMNAME)\
public:\
	ScSystemTime MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){*(ScSystemTime*)nMemName = MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME = *(ScSystemTime*)nMemName;}\

#define _MEM_DEFINE_BOOL(MEMNAME)\
public:\
	bool MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){*(bool*)nMemName = MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME = *(bool*)nMemName;}\

#define _MEM_DEFINE_SDS(SDSNAME, MEMNAME)\
public:\
	SDSNAME MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){nMemName = (void *)&MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME.Copy((IDataContainer*)nMemName);}\

#define _MEM_DEFINE_VAR(MEMNAME)\
public:\
	ScVariant MEMNAME;\
public:\
	void _Get##MEMNAME(void* &nMemName){*static_cast<ScVariant*>(nMemName) = MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){MEMNAME = *(ScVariant*)(nMemName);}\


#define _MEM_DEFINE_ARRAY_INT(MEMNAME, LEN)\
public:\
	int MEMNAME[LEN];\
public:\
	void _Get##MEMNAME(void* &nMemName){nMemName = (void *)MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){memcpy(MEMNAME, nMemName, sizeof(int)*LEN);}\

#define _MEM_DEFINE_ARRAY_FLOAT(MEMNAME, LEN)\
public:\
	float MEMNAME[LEN];\
public:\
	void _Get##MEMNAME(void* &nMemName){nMemName = (void *)MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){memcpy(MEMNAME, nMemName, sizeof(float)*LEN);}\

#define _MEM_DEFINE_ARRAY_TIME(MEMNAME, LEN)\
public:\
	ScSystemTime MEMNAME[LEN];\
public:\
	void _Get##MEMNAME(void* &nMemName){nMemName = (void *)MEMNAME;}\
	void _Set##MEMNAME(void* nMemName){memcpy(MEMNAME, nMemName, sizeof(ScSystemTime)*LEN);}\

#define _MEM_DEFINE_ARRAY_BOOL(MEMNAME, LEN)\
public:\
	bool MEMNAME[LEN];\
public:\
	   void _Get##MEMNAME(void* &nMemName){nMemName = (void *)MEMNAME;}\
	   void _Set##MEMNAME(void* nMemName){memcpy(MEMNAME, nMemName, sizeof(bool)*LEN);}\

	
#define _MEM_DEFINE_ARRAY_SDS(SDSNAME, MEMNAME, LEN)\
public:\
	SDSNAME MEMNAME[LEN];\
	IDataContainer * p##MEMNAME[LEN];	\
public:\
	void _Get##MEMNAME(void* &nMemName){ 		\
	IDataContainer **s##MEMNAME = p##MEMNAME;	\
	for(int i=0; i<LEN; i++){					\
	*(s##MEMNAME++) = (IDataContainer*)(&MEMNAME[i]);			\
	}											\
	nMemName = (void*) p##MEMNAME ;				\
	}\
	void _Set##MEMNAME(void* nMemName){						\
		IDataContainer **p = (IDataContainer**)nMemName;		\
		for (int i=0; i<LEN; i++){MEMNAME[i].Copy(*p);p++;}	\
	}\







