#include <string.h>
#include <string>
#include "ScType.h"
using namespace std;

class SCFL_API ScVariant
{
public:
    ScVariant();
    ScVariant(int iSrc);
    ScVariant(float fSrc);
    ScVariant(bool bSrc);
    ScVariant(string sSrc);
    ScVariant(const char* sSrc);
    ScVariant(ScSystemTime tSrc);
    ~ScVariant();

public:
    ScVariant& operator=(int iSrc);
    ScVariant& operator=(float fSrc);
    ScVariant& operator=(bool bSrc);
    ScVariant& operator=(string sSrc);
    ScVariant& operator=(const char * sSrc);
    ScVariant& operator=(ScSystemTime tSrc);

    operator int();
    operator float();
    operator bool();
    operator string();
    operator ScSystemTime();
    
private:
    string m_sdata;
};


