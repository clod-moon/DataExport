#ifndef CSCDCXMLASSIST_H
#define CSCDCXMLASSIST_H
#include "ScProXml.h"
#include "IDataContainer.h"

class CScDCXMLAssist 
{
public:
	CScDCXMLAssist();
	~CScDCXMLAssist();
public:
	ScErr SaveFile(IDataContainer* sds, const char *szFileName);
	ScErr LoadFile(IDataContainer* &sds, const char *szFileName);
	ScErr LoadSDS(IDataContainer* &sds, const char *szFileName);
	ScErr LoadDC(IDataContainer* &sds, const char *szFileName);

	ScErr Set(IDataContainer* sds, char* &buffer);
	ScErr Get(IDataContainer* &sds, char* buffer);
	ScErr GetSDS(IDataContainer* &sds, char* buffer);
	ScErr GetDC(IDataContainer* &sds, char* buffer);
private:
	ScErr Set(IDataContainer* sds, CSProXml *m_pProXml, SPAPNodePtr RootNodePtr=NULL);
	ScErr Get(IDataContainer* &sds, CSProXml *m_pProXml, SPAPNodePtr RootNodePtr=NULL);
	ScErr GetSDS(IDataContainer* &sds, CSProXml *m_pProXml, SPAPNodePtr RootNodePtr=NULL);
	ScErr GetDC(IDataContainer* &sds, CSProXml *m_pProXml, SPAPNodePtr RootNodePtr=NULL);
};

#endif
