//#include "SCDef.h"

/** @file ScDAT.h
* @brief ���ݿ����ӿ�
*/

#include "ScOSCopy.h"
#include "ScType.h"

/* Define CACHE wait flag */
typedef enum {
	CACHE_NOWAIT = 0,
	CACHE_WAIT   = 1
} CACHE_Wait;

#ifdef __cplusplus
extern "C" {
#endif

#define TestDAT 1

SCFL_API int scDatCopy(void *srcBuff,void *dstBuff,int byteCnt);

SCFL_API int scDatCopy1d(void *srcBuff,void *dstBuff,int byteCnt);

SCFL_API int scDatCopy2d(int type, void *srcBuff, void *dstBuff, int lineLen,int lineCnt, int linePitch);

SCFL_API void scDatWait(int waitId);

SCFL_API void scCacheInvL2(void *blockPtr,int byteCnt,int wait);

#ifdef __cplusplus
}
#endif