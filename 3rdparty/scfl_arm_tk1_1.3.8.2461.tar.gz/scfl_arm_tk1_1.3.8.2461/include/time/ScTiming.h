﻿#ifndef SC_TIMING_H
#define SC_TIMING_H

#include "ScType.h"
#include "ScErr.h"

typedef enum
{
	_BAUD_115200,
	_BAUD_38400,
	_BAUD_19200,
	_BAUD_9600,
	_BAUD_4800,
	_BAUD_2400,
	_BAUD_1200,
	_BAUD_300,
}BaudFlag;

typedef enum
{
	PARTITY_NONE,
	PARTITY_ODD,
	PARTITY_EVEN,
	PARTITY_SPACE,
}ParityFlag;

typedef enum
{
	DATABIT_8,
	DATABIT_7,
}DatabitFlag;

typedef enum
{
	STOPBIT_1,
	STOPBIT_2,
}StopbitFlag;

typedef struct tagComPortInfo
{
	char strDev[100];
	BaudFlag baud;
	DatabitFlag databit;
	StopbitFlag stopbit;
	ParityFlag partitybit;
	tagComPortInfo()
	{
		strDev[0] ='\0';
		baud = _BAUD_4800;
		databit = DATABIT_8;
		stopbit = STOPBIT_1;
		partitybit = PARTITY_NONE;
	};
}ComPortInfo;


#ifdef __cplusplus
extern "C" {
#endif 

/**
*@brief 从串口获取GPS时间
*@param[in] spi 串口参数
*@param[in] datetime 获取到的GPS时间
*@return 错误码
*@see ScErr.h
*/
SCFL_API ScErr scGetGpsTime(ComPortInfo& spi,ScSystemTime& datetime);

#ifdef __cplusplus
}
#endif 

#endif //SC_TIMING_H

