#ifndef _SC_FMT_JPEG_H__
#define _SC_FMT_JPEG_H__
#include "ScType.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum ScImageEncoderParamType
{
	SC_ENCODER_PARAM_JPEG_QUALITY=0,
	SC_ENCODER_PARAM_COUNT
}ScImageEncoderParamType;

typedef struct _ScImageEncoderParam
{
	ScImageEncoderParamType type;
	int value;
}ScImageEncoderParam;

/////////////////////// JpegEncoder ///////////////////
SCFL_API HANDLE 		scJpegEncoderCreate();
SCFL_API void  			scJpegEncoderDestroy(HANDLE	hEncoder);
SCFL_API BOOL  			scJpegEncoderIsFormatSupported(ScImageType type ) ;
SCFL_API BOOL  			scJpegEncoderSetDstMem( HANDLE hEncoder,unsigned char * buf,int size);
SCFL_API BOOL  			scJpegEncoderWrite( HANDLE hEncoder,const ScImage *img,const ScImageEncoderParam params[],int count_param,int * size_write);
/////////////////////// JpegDecoder ///////////////////
SCFL_API HANDLE 		scJpegDecoderCreate(ScImageType type);
SCFL_API void  			scJpegDecoderDestroy(HANDLE hDecoder);
SCFL_API BOOL  			scJpegDecoderIsFormatSupported(ScImageType type ) ;
SCFL_API BOOL  			scJpegDecoderSetDstImageType(HANDLE hDecoder,ScImageType type);
SCFL_API ScImageType  scJpegDecoderGetDstImageType(HANDLE hDecoder);
SCFL_API BOOL  			scJpegDecoderReadData( HANDLE hDecoder, ScImage ** ppImage ,unsigned char * jpeg_data ,int size_data);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif

