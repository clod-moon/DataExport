#ifndef _SCIMAGEPROCESS_H
#define _SCIMAGEPROCESS_H

#include "ScType.h"

#  ifdef __cplusplus
extern "C" {
#  endif /* __cplusplus */

SCFL_API void  		scImageCreateGray( ScImage *pImage, int nWidth, int nHeight, unsigned char *pYData );

SCFL_API ScImage* scImageCrop(ScImage* pImg, ScRect rect);//��ͼ���л�ȡͼ���
//SCAPI(ScImage *) scCreateImageHeader(int patchW,int patchH,int depth,int channels,int imgType);//������imageData����������ṹ


SCFL_API void  		scImageAvgSdv(ScImage *pGrayImg, double*pMean, double *pStd, ScImage *pMask);//��дopencv��cvAvgSdv����
SCFL_API void  		scImageThreshold(ScImage *pGrayImg, ScImage *pDstImg, double thresh, unsigned char Maxval, int type);//��дopencv��cvThreshold
SCFL_API void  		scImageMatchTemplate(ScImage *pGrayImg, ScRect srcRect, ScImage *pTempl, ScImage *pResult, int type);//��дopencv��cvMatchTemplate,pGrayImg��templΪcharͼ��pResultΪfloatͼ��
SCFL_API void  		scImageIntegral(ScImage *pGrayImg, ScImage* sum, ScImage *sqsum);//��дopencv��cvIntegral����֧��pGrayImg1��char���͵ĻҶ�ͼ��sum��int���ͻҶ�ͼ��sqsum��int���ͻҶ�ͼ
SCFL_API int 		scImageMultiplySum(ScImage *pGrayImg1, ScRect rect1,ScImage *pGrayImg2,ScRect rect2);//����ͼ����˺�
SCFL_API void  		scImageResize(ScImage *pImg, ScImage *pImgOut);//���Բ�ֵ����ͼ���С
SCFL_API void  		scImageCropResize(ScImage *pImg,ScRect SrcRect, ScImage *pImgOut);//��ԭͼ�Ͽٲ���ͼ���Բ�ֵ����ͼ���С

SCFL_API void  		scImageMinMaxLoc(ScImage *pImg, float *pfMin, float *pfMax, ScPoint *pMinLoc, ScPoint *pMaxLoc, ScImage *pMask);//opencv de cvMinMaxLoc

SCFL_API void  		scImageDilate(ScImage* pImgIn, ScImage*pImgOut, char* pTempl, int nTemplW, int nTemplH);//dilate
SCFL_API void  		scImageDilateRect(ScImage* pImgIn, ScImage*pImgOut, int nTemplW, int nTemplH);//dilate��ģ��Ϊrect

SCFL_API void  		scImageErode(ScImage* pImgIn, ScImage*pImgOut, char* pTempl, int nTemplW, int nTemplH);//erode
SCFL_API void  		scImageErodeRect(ScImage* pImgIn, ScImage*pImgOut, int nTemplW, int nTemplH);//erode��ģ��Ϊrect

SCFL_API void  		scImageNot(ScImage* pImgIn, ScImage*pImgOut);//not
SCFL_API void  		scImageAnd(ScImage* pImgIn1, ScImage* pImgIn2, ScImage*pImgOut);//and
SCFL_API ScRect	scImageRegionFill(ScPoint SeedPoint, ScImage *pImgIn, ScImage *pImgOut, int nLabel);

SCFL_API void  		scRGB2Gray(ScImage *pSrc,ScImage *pDst);
SCFL_API void  		scImageFindContour(ScImage* pImgIn, ScImage *pImgOut, ScRect *pRectsOut, int *pnLabels, char *pTempl, int nTemplW, int nTemplH);
SCFL_API void  		scImageMaskLabel(
					ScRect *ROIs,
					int *pnLabelCount,
					unsigned char *imgBinary,
					int nWidth,
					int nHeight,
					int *Buffer
					);//��ͨ������ȡ
SCFL_API void  		scDrawRectangle(ScImage *img,ScRect* rect,ScRGB rgb,ScYUV yuv,BOOL bDSP,int nThick);


/****************************************************************************************\
*                                 Image Denoising                                        *
\****************************************************************************************/
/**
 @brief ͼ����
 @param pSrcImg The source image
 @param pDstImg The destination image
 @param nDenoiseType ��������, ��ǰֻ֧����ֵ�˲�����
 @param param1 �������
 @param param2 �������
 @param param3 �������
 @param param3 �������
 @return ScErr
 @see ScErr.h SCImage.h
 @note nDenoiseTypeΪSC_DENOISE_MEDIANʱ	finds the median of a param1  param1 neighborhood (i.e.	the neighborhood is square)
 */
#define SC_DENOISE_MEDIAN	3   //��ֵ�˲�����
SCFL_API ScErr SC_CDECL scImageDenoise(
	ScImage *pSrcImg,			
	ScImage  *pDstImg,			
	int   nDenoiseType,
	int	  param1,
	int   param2,
	double param3, 
	double param4
	);

//////////////////////////////////////////////////////////////////////////
//						���ݾɰ汾�ӿڶ���,���鲻Ҫʹ�����¾ɽӿ�
//////////////////////////////////////////////////////////////////////////
/*
		�ɰ汾					�°汾
		scAvgSdv				scImageAvgSdv
		scThreshold				scImageThreshold
		scMatchTemplate			scImageMatchTemplate
		scIntegral				scImageIntegral
		scMultiplySum			scImageMultiplySum
		scMinMaxLoc				scImageMinMaxLoc
		scImDilate 				scImageDilate 
		scImDilateRect			scImageDilateRect
		scImErode				scImageErode
		scImErodeRect			scImageErodeRect
		scImNot					scImageNot
		scImAnd					scImageAnd
		scRegionFill			scImageRegionFill
		scFindContour			scImageFindContour
		scMaskLabel				scImageMaskLabel
		ScImageDenoise			scImageDenoise
		scCropImageY			ɾ������ʹ��scImageCreateFrom
*/
#  ifdef __cplusplus
}
#endif 
#endif

