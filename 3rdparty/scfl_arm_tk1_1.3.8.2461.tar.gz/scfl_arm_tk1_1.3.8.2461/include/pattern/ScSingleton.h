﻿#pragma once

template<typename TargetType>
class ScSingleton
{
public:
	/*virtual*/ ~ScSingleton(void){}
	static TargetType *GetInstance()
	{
		if (m_instance == NULL)
		{
			m_instance = new TargetType();
		}
		return m_instance;
	}
	static void DestoryInstance()
	{
		if (m_instance != NULL)
		{
			delete m_instance;
			m_instance = NULL;
		}
	}
//protected:
	ScSingleton(void){}

private:
	static TargetType *m_instance;
};

template<typename TargetType>
TargetType *ScSingleton<TargetType>::m_instance = NULL;