#ifndef __IMSGMODULEINTERFACE_H__
#define __IMSGMODULEINTERFACE_H__
/** @file IMsgModuleInterface.h
* @brief ��ϢModule����ӿ�
*/

#include "VasMsg.h"

#ifdef LINUX
#ifndef OUT
#define OUT
#endif
#endif

typedef VRESULT (*SetMsgContentFunc)(IVasMsg *pMsg, MsgContent pContent);
typedef VRESULT (*GetMsgContentFunc)(IVasMsg* pMsg, MsgContent * ppContent,OUT char*szErrDesc, int nErrBufSize);
typedef VRESULT (*DestoryMsgContentFunc)(IVasMsg* pMsg);

typedef struct tagMsgInfo{
	char szStructName[32];		//�ṹ������
	MsgPackType packType;		//msg����
	SetMsgContentFunc setMsgContent;		
	GetMsgContentFunc getMsgContent;
	DestoryMsgContentFunc destoryMsgContent;
}MsgInfo;

/** @class IMsgModule
* @brief MsgModule����ӿ�
*/
class IMsgModule
{
public:
	virtual ~IMsgModule(){}

	virtual VRESULT SetContent(	
		IVasMsg *pMsg, MsgContent content
		) = 0;

	virtual VRESULT GetMsgContent(	
		IVasMsg* pMsg, MsgContent *pContent, OUT char*szErrDesc, int nErrBufSize	
		) = 0;

	virtual VRESULT DestoryMsgContent(
		IVasMsg* pMsg		
		) = 0;	

	virtual VRESULT GetCommandType(	
		const char *pCommand, long *nPackType
		) = 0;

	virtual VRESULT DealWithStruct(const char* szContentStructName)
	{
		return VC_MsgRefused;
	}

	//��ȡpacktype���͵���Ϣ����Ϣӳ��
	virtual VRESULT GetMsgInfo(OUT  MsgInfo* msgInfoMap, OUT unsigned int* nMsgInfoCount, int nMsgInfoMax, MsgPackType packType)
	{
		return VC_MsgRefused;
	}
	
	//��ȡmodule��packType���͵�msg������
	virtual unsigned int GetMsgCount(MsgPackType packType)
	{
		return 0;
	}
};

#endif
