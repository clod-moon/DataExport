﻿#ifndef __VASDEF_H__
#define __VASDEF_H__
/** @file VasDef.h
* @brief Vas协议基本类型定义
*/


#ifdef WIN32
#include <Windows.h>
#include <tchar.h>
#include <wtypes.h>
#endif

#include "ScType.h"
#include <string.h>
#include <string>
using namespace std;

typedef char* VaID;
typedef char* VasID;
typedef long NetID;
typedef const char* VasCeneterID;
typedef char* MsgID;

typedef long ProtocolVersion;	// ProtocolDescribeLayer::nVersion
typedef long MsgPackType;	// ProtocolDescribeLayer::nPackType

#define MY_SZLENGTH 128

//-----------------------------------------------------
// protocol type define
//-----------------------------------------------------

#define PROTOCOL_VERSION_VAS	1		// 从1-15是VAS协议
#define PROTOCOL_MIN_VAS		(unsigned int)1
#define PROTOCOL_MAX_VAS		(unsigned int)15
// #define PROTOCOL_VERSION_IVE	2	
#define PROTOCOL_VERSION_IVE	16		// 从16-32是IVE协议
#define PROTOCOL_MIN_IVE		(unsigned int)16
#define PROTOCOL_MAX_IVE		(unsigned int)31

#define IS_VAS_PROTOCOL(ver)	(ver<=PROTOCOL_MAX_VAS && ver>=PROTOCOL_MIN_VAS)
#define IS_IVE_PROTOCOL(ver)	(ver<=PROTOCOL_MAX_IVE && ver>=PROTOCOL_MIN_IVE)

//-----------------------------------------------------
// net msg type define
//-----------------------------------------------------

#define PackType_Unknown	0
#define PackType_XML 1
#define PackType_Bin 2
#define PackType_Other 3

//-----------------------------------------------------
// alarm linkage plan type
//-----------------------------------------------------

#define AL_PLAN_GRID_PTZ	1
#define AL_PLAN_SOUND 2
#define AL_PLAN_SCREEN_WALL	3

//-----------------------------------------------------
// subsystem code
//-----------------------------------------------------

#define VCP_SUB_SYSTEM_GUARD	1
#define VCP_SUB_SYSTEM_LPR		2
#define VCP_SUB_SYSTEM_TRAFFIC	3

//-----------------------------------------------------
//	error code
//-----------------------------------------------------
typedef long VRESULT;

#define VC_Fail						0
#define VC_OK						1
#define VC_MsgRefused				2
//hecf [Mark]2011-6-3 多线程，如果没有多余的数据库连接，需要将返回一个特定信息，使消息继续停留在消息队列中
#define VC_NoAvailableDbCon			3	//代表没有可利用的数据库连接
//end [Mark]2011-6-3

#define VC_SUCCEEDED(Status) ((Status) >= 0)

/** @brief 消息类型定义 */	
typedef long MsgCategoray;			//MsgCategoray是表示消息是否需要反馈的属性的，取值如下：
#define MsgCatUnknown				-1	
#define MsgCatRequest				0	//上报, 需要反馈
#define MsgNotice					1	//上报，不需要反馈
#define MsgStatusFeedback			2	//操作状态反馈消息
#define MsgDataFeedback				3	//数据反馈消息
#define IsMsgFeedBack(cat) (((cat) == MsgStatusFeedback) || ((cat) == MsgDataFeedback))

#define VC_FAILED(Status) ((Status)<0)

#define StatusFeedBackMsgCmd	"StatusFeedBackMsg" 

/** @brief 状态反馈结构体 */	
struct FeedBackMsg
{
	FeedBackMsg()
	{
		lStatus = 0;
		szErrDesc[0] = '\0';
	}
	int lStatus;   //操作状态
	char szErrDesc[256];	//数据, MsgStatusFeedback pData=NULL, 其他为数据
};
#endif
