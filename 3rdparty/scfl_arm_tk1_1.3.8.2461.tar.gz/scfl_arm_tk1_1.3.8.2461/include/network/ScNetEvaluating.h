#ifndef NET_EVALUATING_EXPORT_H
#define NET_EVALUATING_EXPORT_H

/** @file ScNetEvaluating.h
* @brief ���绷������
*/

#include "ScType.h"

/** @brief ���绷��״̬ */	
typedef enum _netstate
{
	NETFLOW = 0,		//��������
	NETCONGESTIVE,		//����ӵ��
	NETTERRIBLE,		//�������
	NETBLOCKED			//�������
}NETSTATE;

typedef void* HNEC;
typedef void* HNES;
typedef void (*NetRTInfo)(const char* szClientIP,unsigned int uPackSize,ScSystemTime scSendTime,ScSystemTime scRebackTime,int nRTTMilliSeconds);
typedef void (*NetCollect)(const char* szClientIP,int nQuickTime,int nSlowTime,int nAverageTime,NETSTATE state);

#ifdef __cplusplus
extern "C" {
#endif

SCFL_API HNEC scNeClientCreate(const char* szServerIP,unsigned int uServerPort);
SCFL_API void  scNeClientDestory(HNEC hNec);
SCFL_API void  scNeClientStart(HNEC hNec);
SCFL_API void  scNeClientStop(HNEC hNec);

SCFL_API HNES scNeServerCreate(unsigned int uPort, unsigned int nSendInterval, unsigned int uPackSize,unsigned int uRunTime,NetRTInfo funRTInfo,NetCollect funRCollect);
SCFL_API void  scNeServerDestory(HNES hNes);
SCFL_API void  scNeServerStart(HNES hNes);
SCFL_API void  scNeServerStop(HNES hNes);


#ifdef __cplusplus
}
#endif

#endif