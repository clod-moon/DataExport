﻿#pragma once
/**
* @file VasMsgImpl.h
* @brief VasMsg工厂实现
*/

#include <string>
using namespace std;
#include "VasMsg.h"
#include "ScMutex.h"

// 消息头处理
// +-------------------------------------------------------------------------------------
// |					|    Version    |  Cont Type  |
// +-------------------------------------------------------------------------------------

/**
* @class CVasMsgImpl
* @brief VasMsg工厂抽象接口实现
*/
class SCFL_API CVasMsgImpl
	:public IVasMsg
{
public:
	CVasMsgImpl(void);
	virtual ~CVasMsgImpl(void);

public:
	virtual void AddRef();
	virtual long Release();

public:
	virtual long GetProtocolVersion(){return m_nVersion;};

public:
	virtual const char* GetMsgId(){return m_sMsgId.c_str();};
	virtual MsgCategoray GetMsgCategoray(){return m_nCat;};
	virtual const char* GetCommand(){return m_sCommand.c_str();};
	virtual const char* GetContentStructName(){return m_sContentStructName.c_str();};	// 可能为NULL或""
	virtual const char* GetSource(){return m_sSource.c_str();};			// 可能为NULL或""
	virtual const char* GetDestination(){return m_sDestination.c_str();};		// 可能为NULL或""

public:
	virtual char* GetBuf();
	virtual long GetBufLen();

protected:
	/*
	*	@brief	接收到网络消息时，从网络流创建VasMsg
	*/
	virtual VRESULT CreateFromStream(const char * pBuf, long lBufLen);
	/*
	*	@brief	将要发送网络消息时，从本地参数创建VasMsg
	*/
	 virtual VRESULT CreateHeader(MsgID id, MsgCategoray cat, const char * szCommand,
	 	const char* szContentStructName, const char* szSource=NULL, const char* szDestination=NULL);

	// virtual VRESULT SetContent(MsgContent content=NULL) = 0;
	/***不管有没有content都可以以此尝试清空***/
	virtual VRESULT DestroyContent();
	// virtual VRESULT GetMsgContent(OUT MsgContent *pContent) = 0;
	// virtual VRESULT GetMsgContentInstance(OUT MsgContent *pContent) = 0;
	/***获取IVE_IVasMsg类型***/
	// virtual __NetDataType GetMsgType()const = 0;


public:
	static VRESULT GetMsgHeaderFromStream(const char * pBuf, long lBufLen,
		OUT char* szCommand, OUT int& nCategory, OUT char* szSource, OUT char* szDestination) ;

	/*
	*	@brief	MsgCategory与字符串转换函数
	*/
	static MsgCategoray MsgCategoryString2Int(const char* cszCatString);
	static BOOL MsgCategoryInt2String(MsgCategoray cat, OUT char* szCatString);

	// ----------------IVE
protected:

	BOOL SetDispatchInfo(ProtocolDispatchLayer* pDispatch);
public:
	/***Create m_pWholeContent if m_pWholeContent==NULL***/
	BOOL CreateWholeContentBuf(int len);
	// ---------------IVE -end

public:
	long m_nVersion;
	long m_nContentType;	// 仅VAS协议

	string m_sCommand;
	string m_sMsgId;
	MsgCategoray m_nCat;

	string m_sContentStructName;
	string m_sSource;
	string m_sDestination;

	MsgContent m_pWholeContent;		// 注意：此指针指向整个消息的开始，GetBuf时返回它
	long m_nLenWholeContent;
	MsgContent m_pContent;
	long m_nContentLen;

private:
	long m_nRef;
	HSCMutex m_mutex;
};
