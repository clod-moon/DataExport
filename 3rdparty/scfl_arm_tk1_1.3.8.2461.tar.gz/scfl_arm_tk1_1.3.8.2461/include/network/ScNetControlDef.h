﻿#ifndef _VNET_CONTROL_DEF_H
#define _VNET_CONTROL_DEF_H

// 状态信息标识
#define VNetStatus_SocketLastRecvTime 1	// 在指定SOCKET上收到数据的最后时间, 得到的值的数据类型：SYSTEMTIME

// 数据类型
#define VNetDT_SYSTEMTIME 1	// 对应SYSTEMTIME

#endif