﻿#ifndef __VASMSGXMLIMPL_H__
#define __VASMSGXMLIMPL_H__
/**
* @file VasMsgXmlImpl.h
* @brief VasMsg XML实现
*/
#include "VasMsgImpl.h"
#include "ScProXml.h"

//////////////////////////////////////////////////////////////////////////
//					
//////////////////////////////////////////////////////////////////////////
/**
* @class CVasMsgXmlImpl
* @brief VasMsg抽象接口XML版实现
*/
class SCFL_API CVasMsgXmlImpl
	:public CVasMsgImpl
{
public:
	CVasMsgXmlImpl();
	virtual ~CVasMsgXmlImpl();

public:
	/*
	*	
	*/
	VRESULT CreateFromStream(const char * pBuf, long lBufLen);
	VRESULT CreateHeader(MsgID id, MsgCategoray cat, const char * szCommand,
		const char* szContentStructName, const char* szSource=NULL, const char* szDestination=NULL);

	virtual VRESULT SetContent(MsgContent content=NULL);
	virtual VRESULT DestroyContent();
	virtual VRESULT GetMsgContent(OUT MsgContent *pContent);
	virtual VRESULT GetMsgContentInstance(OUT MsgContent *pContent);
	__NetDataType GetMsgType()const;

	// CVasMsgXmlImpl:
	// +------------------------------------------------------------------------------------------------
	// |    Version    |  Cont Type  |	
	// +------------------------------------------------------------------------------------------------
	virtual char *GetBuf();
	virtual long GetBufLen();

	//
	VRESULT GetMsgHeaderFromStream(const char * pBuf, long lBufLen,
		OUT char* szCommand, OUT int& nCategory, OUT char* szSource, OUT char* szDestination) ;
private:
	VRESULT DoGetHeaderFromStream(CSProXml* pDoc);

public:
	string m_sContent;			// 
	CSProXml *m_pXmlDoc;
};

#endif
