﻿/**
* @file VasModuleDef.h
* @brief Vas通信插件定义
* @note 建议弃用，使用函数入口定位方式加载插件
*/

#ifndef MODULEDEF_H_
#define MODULEDEF_H_

// MsgFactory支持的最大功能集

// Module开发者在此添加自己的对象类型，切记不要修改自己不知道的东西。另外，要加在TotalModule之前。

/** @brief MsgFactory支持的最大功能集 */	
enum Identify_of_MsgModules
{
	// 业务Module
	eum_Identify_of_GuardModule = 0,
	eum_Identify_of_DensityModule,
	eum_Identify_of_LprModule,
	eum_Identify_of_TrafficModule,
    eum_Identify_of_CountMsgModule,
    eum_Identify_of_AssistMsgModule,
    eum_Identify_of_PCMsgModule,
	eum_Identify_of_DiagnoseMsgModule,
	eum_Identify_of_SecurityMsgModule, 

	// 公共Module
	eum_Identify_of_AlarmlinkageXmlMsgModule,
	eum_Identify_of_CommonXmlMsgModule,
	eum_Identify_of_CommonBinaryMsgModule,
	//HSC
	Identify_of_IMsgModule,
	enm_Identify_of_SenceMsgModule,	//场景处理的Module
	eum_Identify_of_TotalModule,		// 总和
};
#endif /* MODULEDEF_H_ */
