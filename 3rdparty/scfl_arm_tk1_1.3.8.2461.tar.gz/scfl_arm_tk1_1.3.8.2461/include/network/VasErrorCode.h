﻿#pragma once
/** @file VasErrorCode.h
* @brief Vas协议网络错误码定义
* @note 请与ScErr区分，该错误码仅用于Vas网络通信
*/


//这套错误码只要是在VasTI和VasMC中使用的，是 VCErr_开头
//而VasMsg中主要使用 VC_ 开头的错误码
//////////////////////////////////////////////////////////////////////////
// Basic
#define VTErr_Success				0	// 操作成功
#define VTErr_LogicalErr			5	// 内部逻辑错误
#define VTErr_AccessNULL			10	// 访问空地址
#define VTErr_MemLow				15	// 内存不足
#define VTErr_AccessOutOfRange		20	// 数组访问越界
#define VTErr_FuncParamInvalid		25	// 函数参数输入不正确
#define VTErr_UnSupportedOperation	30	// 不支持的操作

#define VTErr_AccessDbFailed		150	// 访问数据库错误
#define VTErr_NetTimeOut			200	// 网络超时
#define VTErr_ServerConnectFailed	205	// 没有连接到文安应用服务器
#define VTErr_VANotOnline			210	// VAServer未连接
#define VTErr_GetBitmapFailed		215	// 无法获取截图
#define VTErr_UserVerifyFailed	220	// 登陆验证错误

#define VTErr_Unknown			-1000	// 未知错误


