﻿/*
 * ProtocolCheck.h
 *
 *  Created on: 2012-1-6
 *      Author: will
 */

 /** @file ScProtocolCheck.h
* @brief 协议版本检查接口
* @note 基本已弃用
*/


#ifndef PROTOCOLCHECK_H_
#define PROTOCOLCHECK_H_


#define PROTOCOL_UNKNOWN 0
#define PROTOCOL_V1 1
#define PROTOCOL_V2 2

#include "ScType.h"

 /** @class CProtocolCheck
* @brief 协议版本检查类
* @note 基本已弃用
*/
class SCFL_API CProtocolCheck
{
public:
	CProtocolCheck(void);
	~CProtocolCheck(void);
public:
	static long GetProtocolVersion(const char * pBuf, long lBufLen);
	static bool IsVerII_BinaryMsg(const char * pBuf, long lBufLen);
};


#endif /* PROTOCOLCHECK_H_ */
