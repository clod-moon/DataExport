﻿#ifndef __VASMSGBINARYIMPL_H__
#define __VASMSGBINARYIMPL_H__
/**
* @file VasMsgBinaryImpl.h
* @brief VasMsg 二进制实现
*/

#include "VasMsgBaseDef.h"
#include "VasMsgImpl.h"
//////////////////////////////////////////////////////////////////////////
//						Binary版本IVasMsg实现
//////////////////////////////////////////////////////////////////////////

/**
* @class CVasMsgBinaryImpl
* @brief VasMsg抽象接口二进制版实现
*/
class SCFL_API CVasMsgBinaryImpl
	:public CVasMsgImpl
{
public:
	CVasMsgBinaryImpl();
	virtual ~CVasMsgBinaryImpl();

public:
	/*
	*	@brief 以下这些接口是给上层使用的，不是给VcpModule使用的
	*/
	VRESULT CreateFromStream(const char * pBuf, long lBufLen);
	VRESULT CreateHeader(MsgID id, MsgCategoray cat, const char * szCommand,
		const char* szContentStructName, const char* szSource=NULL, const char* szDestination=NULL);

	virtual VRESULT SetContent(MsgContent content=NULL);
	virtual VRESULT DestroyContent();
	virtual VRESULT GetMsgContent(OUT MsgContent *pContent);
	virtual VRESULT GetMsgContentInstance(OUT MsgContent *pContent);
	__NetDataType GetMsgType()const;

	virtual VRESULT CreateBufByContentLen(int nContentBufSize, OUT BOOL& bBufExistAlready);

	// CVasMsgBinaryImpl::GetBuf返回结构如下
	// +------------------------------------------------------------------------------------------------
	// |    Version    |  Cont Type  |	  二进制消息头  |   二进制消息体
	// +------------------------------------------------------------------------------------------------
	virtual char *GetBuf();	
	virtual long GetBufLen();
	// 从接收到的数据读出协议头的信
	VRESULT GetMsgHeaderFromStream(const char * pBuf, long lBufLen,		OUT char* szCommand, OUT int& nCategory, OUT char* szSource, OUT char* szDestination) ;
private:
	// 返回值：VC_OK-操作成功，VC_Fail-操作失败
	VRESULT DoGetHeaderFromStream(const char * pBuf, long lBufLen);//add for count

public:
	ProtocolDispatchLayer m_header;
};

#endif
