﻿#ifndef __VASMSG_H__
#define __VASMSG_H__

/**
* @file VasMsg.h
* @brief VasMsg、VasMsg工厂抽象接口定义
*/

#include "VasDef.h"
#include "VasMsgBaseDef.h"
#include <list>
#include "IVE_Const.h"

/** @brief 消息内容Buffer定义 */	
typedef void * MsgContent;

/**
* @class IVasMsg
* @brief VasMsg抽象接口定义
*/
class IVasMsg
{
protected:
	virtual ~IVasMsg(){}

public:
	virtual void AddRef() = 0;
	virtual long Release() = 0;

public:
	virtual long GetProtocolVersion() = 0;//add for count

public:
	virtual const char* GetMsgId() = 0;
	virtual MsgCategoray GetMsgCategoray() = 0;
	virtual const char* GetCommand() = 0;
	virtual const char* GetContentStructName() = 0;	// 消息主体内容转换为结构体时该结构体的名称，可能为NULL或""
	virtual const char* GetSource() = 0;			// 可能为NULL或""
	virtual const char* GetDestination() = 0;		// 可能为NULL或""

public:
	virtual char* GetBuf() = 0;		// 获取消息体
	virtual long GetBufLen() = 0;

protected:
	friend class IVasMsgFactory;
	friend class CMsgFactoryImpl;

	/*
	*	@brief	接收到网络消息时，从网络流创建VasMsg
	*/
	virtual VRESULT CreateFromStream(const char * pBuf, long lBufLen) = 0;
	/*
	*	@brief	将要发送网络消息时，从本地参数创建VasMsg
	*/
	virtual VRESULT CreateHeader(MsgID id, MsgCategoray cat, const char * szCommand,
		const char* szContentStructName, const char* szSource=NULL, const char* szDestination=NULL) = 0;
	virtual VRESULT SetContent(MsgContent content=NULL) = 0;

	/***不管有没有content都可以以此尝试清空***/
	virtual VRESULT DestroyContent() = 0;
	virtual VRESULT GetMsgContent(OUT MsgContent *pContent) = 0;
	virtual VRESULT GetMsgContentInstance(OUT MsgContent *pContent) = 0;
	static VRESULT PutMsgContentInstance(MsgContent msgContent, __NetDataType typeContent);
	/***获取IVE_IVasMsg类型***/
	virtual __NetDataType GetMsgType()const = 0;
};

/**
* @class IVasMsg
* @brief VasMsg工厂抽象接口定义
*/
class IVasMsgFactory
{
public:
	virtual ~IVasMsgFactory(){};

	virtual void GetErrorModule(list<string>* pliModule)=0;//增返回装入MODOULE的错误信息
	
	virtual void AddRef(IVasMsg *pMsg) = 0;
	virtual void Release(IVasMsg *pMsg) = 0;

	//由接收到的数据创建msg
	virtual VRESULT CreateFromStream(IVasMsg **ppMsg, const char * pBuf, long lBufLen) = 0;

	//由本地数据结构创建msg，重载A
	virtual VRESULT CreateFromContent(
		IVasMsg **ppMsg, 
		const char* id, MsgCategoray cat, const char * szCommand, const char* szContentStructName,
		MsgContent content,  //消息的内容, 结构体或者对像指针
		const char* szSource = NULL, const char* szDestination = NULL, 
		MsgPackType packtype = PackType_XML
		) = 0;	// 如果szCommand仅对应一个消息体，则szContentStructName可以为NULL

	//由本地数据结构创建msg，重载B
	virtual VRESULT CreateFromContent(
		IVasMsg **ppMsg, IVasMsg *pPreMsg, 
		const char* id, MsgCategoray cat, const char * szCommand, const char* szContentStructName,
		MsgContent content,  //消息的内容, 结构体或者对像指针
		const char* szSource = NULL, const char* szDestination = NULL
		) = 0;	// 如果szCommand仅对应一个消息体，则szContentStructName可以为NULL

	// 提供协议选择接口，重载C
	virtual VRESULT CreateFromContent(
		IVasMsg OUT **ppMsg,
		ProtocolVersion ProtocolVer, 
		const char* id, MsgCategoray cat, const char * szCommand, const char* szContentStructName,
		MsgContent content,  //消息的内容, 结构体或者对像指针
		const char* szSource = NULL, const char* szDestination = NULL,
		MsgPackType packtype = PackType_XML
		) = 0;

	// 从接收到的数据读出协议头的信息(szCommand, szSource, szDestination的长度要大于32，否则会出错)
	virtual VRESULT GetMsgHeaderFromStream(const char * pBuf, long lBufLen, 
		OUT char* szCommand, OUT int& nCategory, OUT char* szSource, OUT char* szDestination) = 0;

	virtual VRESULT DestoryMsg(IVasMsg **ppMsg) = 0;

	virtual VRESULT CreateMsgID(char id[MY_SZLENGTH]) = 0;  //不用string *返回

	//返回结构体或者对像指针
	virtual VRESULT GetMsgContent(IVasMsg* pMsg, MsgContent *pContent, OUT char*szErrDesc, int nErrBufSize) = 0;
};
#endif