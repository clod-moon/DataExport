/*
 * plugins.h
 *
 *  Created on: 2012-1-6
 *      Author: will
 */

/** @file ScPlugins.h
* @brief �������
*/


#ifndef PLUGINS_H_
#define PLUGINS_H_

/** @file ScPlugins.h
* @brief �������
* @note ����C++ RTTI����ʵ�ֵĲ�����
*/

#include <string>
#include <list>
#include<stdio.h>
using namespace std;

#include "ScType.h"
// #include "ScDynLoadShdLib.h"
#include "ScDynLibLoader.h"
#include "ScFileFinder.h"
#include "IMsgModuleInterface.h"
#include "ScMutex.h"

/** @class IPluginsInterface
* @brief �������ӿ�
* @note �ɲ��Module�ڲ�ʵ�֣�ͨ��Nodule������CreateObjects/DestoryObjects���ý���ʵ�����Ĵ���������
*/
class IPluginsInterface
{
public:
	IPluginsInterface(){};
	virtual ~IPluginsInterface(){};

	virtual const char* GetPluginsIdentify() const{	return NULL;}
	virtual void SetPluginsIdentify(const char* tszIdentify){}

	virtual long GetType() const{return type;}

	virtual void SetType(long type){this->type = type;}

public:
	TCHAR m_tszPluginsIdentify[260];
	long type;
};

typedef SCFL_API IPluginsInterface* (SC_STDCALL *PCreateObjects)(long);
typedef SCFL_API long (SC_STDCALL *PDestoryObjects)(IPluginsInterface*, long);

/** @class CPluginsModule
* @brief ���Module��
*/
class SCFL_API CPluginsModule
{
public:
	CPluginsModule()
	{
		m_pCreatePlugins = NULL;
		m_pDestoryPlugins = NULL;
		m_dynLoad = NULL;
	};
	virtual ~CPluginsModule(){};

	long Init(LPCSTR lpszModuleFileName)
	{
#ifndef LINUX
		Destroy();
#endif
		m_dynLoad = scDynLibLoaderCreate();
		if (!m_dynLoad)
		{
			return FALSE;
		}

		if(!scDynLibLoaderLoad(m_dynLoad, lpszModuleFileName))
		{
			return FALSE;
		}

		m_pCreatePlugins = (PCreateObjects)scDynLibLoaderGetProc(m_dynLoad, "CreateObjects");//(PCreateObjects)m_dynLoad.GetProc("CreateObjects");
		if( !m_pCreatePlugins )
		{
			// m_dynLoad.Free();
			scDynLibLoaderFree(m_dynLoad);
			return FALSE;
		}

		m_pDestoryPlugins = (PDestoryObjects)scDynLibLoaderGetProc(m_dynLoad, "DestoryObjects");// (PDestoryObjects)m_dynLoad.GetProc("DestoryObjects");
		if( !m_pDestoryPlugins )
		{
			// m_dynLoad.Free();
			scDynLibLoaderFree(m_dynLoad);
			return FALSE;
		}

		return TRUE;
	}

	void Destroy()
	{
		// m_dynLoad.Free();
		scDynLibLoaderFree(m_dynLoad);
	}

public:
	// SCDynLoadShdLib m_dynLoad;
	HDYNLOADER m_dynLoad;
	PCreateObjects m_pCreatePlugins;
	PDestoryObjects m_pDestoryPlugins;
};


/** @class CPluginsContainer
* @brief ���������
*/
class SCFL_API CPluginsContainer
{
public:
	CPluginsContainer()
	{
		m_mutex = scCreateMutex();
	}
	virtual ~CPluginsContainer()
	{
		scDestroyMutex(m_mutex);
	}
#ifdef LINUX
BOOL iscmp (string source,string filter)
{
	 unsigned index = 0;
	 int location = -1;
	 string arrFilter[5] = {"","","","",""};
	 do
	 {
	     location = filter.find("*");
	     if(location == 0)
	     {
	          filter = filter.substr(1,filter.size()-1);

	     }
	     if(location > 0)
	     {
	          arrFilter[index] = filter.substr(0,location);
	          filter = filter.substr(location+1,filter.size()-location-1);
	          index ++;
	     }
	 }while(location != -1);
	if(filter.length() > 0)
	{
                arrFilter[index] = filter;
                index ++;
	}
	unsigned i,j;
	unsigned count = 0;
	for(i=0; i<index; i++)
	{
		if(arrFilter[i] != "")
		{
			string sTemp;
			for(j=0; j<source.size(); j++)
			{
				sTemp = source.substr(j,arrFilter[i].size());
				if(sTemp == arrFilter[i])
				{
					source = source.substr(j+arrFilter[i].size(),source.size()-j-arrFilter[i].size());
					count ++;
					break;
				}
			}
		}
	}
	if(count == index)
	{
	      return TRUE;
	}
	return FALSE;
}
#endif

	void LoadPlugins(LPCTSTR lpszPluginDir, LPCTSTR lpszPluginFilter, list<string>* plist=NULL)
	{
		list<string> listPluginsName;
		char tszFileName[MAX_PATH] = "\0";
		char tszPluginDir[MAX_PATH] = "\0";
		char* pszFileName = (char*)tszFileName;
		strcpy(tszPluginDir, lpszPluginDir);

		size_t dn = strlen(tszPluginDir);
#ifndef LINUX
		if (tszPluginDir[dn] != '\\')
			strcat(tszPluginDir, "\\");
		if (strlen(lpszPluginFilter) <= 0)
			sprintf(pszFileName, "%s*MsgModule*.dll", tszPluginDir);
		else
			sprintf(pszFileName, "%s%s", tszPluginDir, lpszPluginFilter);
#else
		if (tszPluginDir[dn] != '/')
			strcat(tszPluginDir, "/");
		if (strlen(lpszPluginFilter) <= 0)
			sprintf(pszFileName, "%s*MsgModule*.so", tszPluginDir);
		else
			sprintf(pszFileName, "%s%s", tszPluginDir, lpszPluginFilter);
#endif
		// CSCFileFinder finder(tszPluginDir);
		HFILEFIND hfinder = scFileFinderCreate(tszPluginDir);
		// BOOL bFind = finder.FindFile(lpszPluginFilter);
		BOOL bFound = scFileFinderFind(hfinder, lpszPluginFilter);
		while( bFound )
		{
			// bFind = finder.FindNextFile();
			bFound = scFileFinderFindNext(hfinder);

			// if( bFound && !finder.IsDirectory() && !finder.IsDots() )
			if( bFound && !scFileFinderIsDots(hfinder) && !scFileFinderIsDirectory(hfinder) )
			{
				char szFileName[MAX_PATH];
				char szTemp[MAX_PATH];
				// finder.GetFileName(szFileName);
				scFileFinderGetName(hfinder, szFileName);
				sprintf(szTemp,"%s%s",tszPluginDir,szFileName);
				listPluginsName.push_back(szTemp);
			}
		}

		for(list<string>::iterator iter = listPluginsName.begin(); iter != listPluginsName.end(); iter++)
		{
			CPluginsModule *pModule = new CPluginsModule();
			string szTemp = (*iter);
			if(pModule->Init(szTemp.c_str()))
			{
				// ���سɹ�
				m_vPluginsModule.push_back(pModule);
			}
			else
			{
				// ����ʧ��
				delete pModule;
				if( plist )
					plist->push_back(*iter);
			}
		}
	}
	void UnloadPlugins()
	{
		for(list<CPluginsModule*>::iterator iter = m_vPluginsModule.begin(); iter != m_vPluginsModule.end(); iter ++)
		{
			if(*iter)
			{
				(*iter)->Destroy();
				delete *iter;
			}
		}
		m_vPluginsModule.clear();
	}

	list<IMsgModule*> QueryObjects(long type)
	{
		list<IMsgModule*> vPlugins;
		scLockMutex(m_mutex);
		for(list<CPluginsModule*>::iterator iter = m_vPluginsModule.begin(); iter != m_vPluginsModule.end(); iter++)
		{
			if(*iter)
			{
				IPluginsInterface *pInterface = (*iter)->m_pCreatePlugins(type);
				if (pInterface)
				{
					try
					{
						pInterface->SetType(type);
						IMsgModule *pObj = dynamic_cast<IMsgModule*>(pInterface);
						vPlugins.push_back(pObj);
					}
					catch (...)
					{
						(*iter)->m_pDestoryPlugins(pInterface,pInterface->GetType());
					}
				}
			}
		}
		scUnlockMutex(m_mutex);
		return vPlugins;
	}
	void ReleaseObjects(list<IMsgModule*> vPlugins)
	{
		scLockMutex(m_mutex);
		for(list<IMsgModule*>::iterator iterplugin = vPlugins.begin(); iterplugin != vPlugins.end(); iterplugin ++)
		{
			if(*iterplugin)
			{
				for(list<CPluginsModule*>::iterator iter = m_vPluginsModule.begin(); iter != m_vPluginsModule.end(); iter ++)
				{
					if(*iter)
					{
						try
						{
							IPluginsInterface *pInterface = dynamic_cast<IPluginsInterface*>(*iterplugin);
							if (pInterface)
							{
								long lRet = (*iter)->m_pDestoryPlugins(pInterface,pInterface->GetType());
								if(lRet == 1)
                                    break;
							}
						}
						catch (...)
						{
							continue;
						}
					}
				}
			}
		}
		scUnlockMutex(m_mutex);
	}

public:
	list<CPluginsModule*> m_vPluginsModule;
	HSCMutex m_mutex;
};

#endif /* PLUGINS_H_ */
