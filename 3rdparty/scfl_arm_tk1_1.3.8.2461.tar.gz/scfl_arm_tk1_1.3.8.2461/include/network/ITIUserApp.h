﻿#pragma once
/** @file ITIUserApp.h
* @brief 应用层网络回调定义
*/

#include "VasMsg.h"
#include "VasTIExport.h"
#include <list>
using namespace std;

#define TIE_NetDisConnected 0	// 网络断开
#define TIE_NetConnected 1		// 网络连接上
#define TIE_ServerAliveTimeout 120	// 服务器心跳反馈超时 //hecf [Mark]2011-6-27 

//liw 20120326 对回调处理消息和事件的回调函数接口都增加一个TI的指针句柄HVASTI参数hTI
//这样可以解决上层有多个作为服务器TI，底层收到的消息和事件就能在上层区分到底是属于
//那一个服务器TI对象的

/** @class ITIUserApp
* @brief 应用层网络回调抽象接口
*/
class SCFL_API ITIUserApp
{
public:
	virtual ~ITIUserApp(){};
	virtual BOOL TIU_IsAppReady() = 0;	// 是否已经准备好（接受函数调用），没准备好则返回0

	virtual void TIU_OnRecvMsg(IVasMsg* pMsg, const char *szIP,ScSocket sFromSocket,HVASTI hTI) = 0;
	// lEvent: 0-网络断开， 1-网络连接上， 5-服务器心跳反馈超时
	virtual	void TIU_OnTIEvent(unsigned long lEvent, const char *szIP,ScSocket sFromSocket,HVASTI hTI) = 0;

	// 是否不处理当前消息而直接转发
	virtual void TIU_OnAutoTransAsk(const char* cszSource,		// 消息来源地
		const char* cszDestination,	// 消息目的地
		const char* cszCommand,
		int nCategory,
		OUT BOOL& bShouldTrans,
		OUT ScSocket& sTransTo) = 0;
};
