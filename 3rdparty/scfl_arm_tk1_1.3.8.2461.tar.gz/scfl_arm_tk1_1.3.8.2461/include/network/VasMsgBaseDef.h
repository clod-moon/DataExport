﻿/**
* @file VasMsgBaseDef.h
* @brief Vas通信协议头定义
* @note 建议弃用
*/

#ifndef MSGBASEDEF_H_
#define MSGBASEDEF_H_

#include "VasDef.h"

//	通用协议形态

//	+---------------------------------------------------------------------------------------------------------------------------------------------------------------------
//	|		VNet头		|		协议描述层（ProtocolDescribeLayer）		|		协议调度层（ProtocolDispatchLayer）		|		协议体
//	|		8 byte		|					8 byte											|					256 byte										|
//	+---------------------------------------------------------------------------------------------------------------------------------------------------------------------




//	+---------------------------------------------------------------------------------------------------------------------------------------------------------------------
//	|		VNet头		|		协议描述层（ProtocolDescribeLayer）		|		协议调度层（ProtocolDispatchLayer）		|		协议体
//	|		8 byte		|					8 byte											|				256 byte											|
//	+---------------------------------------------------------------------------------------------------------------------------------------------------------------------
//
//	XML版本协议形态
//
//	|
//	|<—————————————binary—————————————>	|	<————————————————XML—————————————————>
//
//	Binary版本协议形态
//
//	|
//	|<—————————————————————————————binary————————————————————————————————————>



/** @brief 协议描述层，用于区分协议版本、类型 */	
struct ProtocolDescribeLayer
{	
	int nVersion;	/// 协议版本号，可选项为PROTOCOL_VERSION_VAS、PROTOCOL_VERSION_IVE	
	int nPackType;	/// 当nVersion为PROTOCOL_VERSION_VAS时，消息内容类型：1-XML 2-BINARY 3-OTHER
							// 当nVersion为PROTOCOL_VERSION_IVE时，消息内容类型：0-Config 1-自描述结构体 2-自定义协议
	ProtocolDescribeLayer()
	{
		nVersion = PROTOCOL_VERSION_VAS;	
		nPackType = PackType_Bin;
	}
};

//
//	note:仅供二进制网络消息使用，XML形式的消息派遣层被包含在XML内部
//

/** @brief 协议分发曾，区分消息类型 */	
struct ProtocolDispatchLayer{
	char szMsgID[64];
	char szCommand[32];
	char szCategory[32];	// request/statusfeedback/其他	
	char szContentStructName[32];	// 结构体名称，例如 pciiRegister	
	char szSource[32];		// 消息源	
	char szDestination[32];	// 消息目的地	
	char szReserved[32];	// 保留字段

	ProtocolDispatchLayer()
	{	
		//szMsgID[0] = '\0';	
		//szCommand[0] = '\0';		
		//szCategory[0] = '\0';	
		//szContentStructName[0] = '\0';	
		//szSource[0] = '\0';		
		//szDestination[0] = '\0';		
		//szReserved[0] = '\0';	
		memset(szMsgID, 0, sizeof(szMsgID));
		memset(szCommand, 0, sizeof(szMsgID));
		memset(szCategory, 0, sizeof(szCategory));
		memset(szContentStructName, 0, sizeof(szContentStructName));
		memset(szSource, 0, sizeof(szSource));
		memset(szDestination, 0, sizeof(szDestination));
		memset(szReserved, 0, sizeof(szReserved));
	}
};
#endif /* MSGBASEDEF_H_ */
