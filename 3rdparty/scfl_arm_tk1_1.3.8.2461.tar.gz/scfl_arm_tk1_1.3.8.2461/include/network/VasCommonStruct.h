﻿#pragma once
//#ifndef _VASCOMMONSTRUCT_H_
//#define _VASCOMMONSTRUCT_H_

/** @file VasCommonStruct.h
* @brief Vas协议基本Command定义
*/

#include "VasDef.h"

// 无结构体，content为空
#define AliveCommand	"Alive"
/*
// 结构体参见vvtagVAServer和vvtagVA
#define VasRegisterCommand		"VasRegister"
#define VARegisterCommand	"VARegister"
#define VasTimingCommand		"HSCCheckingVasTimeCommand"			// liux 添加于 2011-09-16 request消息体为空，datafeedback消息体携带VasSystemTime进行反馈，structname为HSCSystemTimeStruct，有关内容详见doc中得《hsc中心校时协议》

// 结构体参见VasBinary
#define VasGuardBinaryCommand	"GuardBin"
#define VasAbbhBinaryCommand	"AbbhBin"
#define VasDensityBinaryCommand	"DensityBin"
#define VasLprBinaryCommand	"LprBin"
#define VasTrafficEventBinaryCommand "TraficEventBin"

// 结构体参见VasConfig和VasNetConfig，在VasDef.h
#define VasClientNetConfigRequestCommand	"VasClientNetConfigRequest"
#define VasClientNetConfigCommand	"VasClientNetConfig"

#define VasCenterRequestDeviceInfoCommand		"VasCenterRequestDeviceInfo"

#define VasDeviceGroupRequestCommand	"DeviceGroupRequest"
#define VasDeviceGroupCommand	"DeviceGroup"
#define VasDGRelationCommand	"DGRelation"
#define VasDGRelationRequestCommand		"DGRelationRequest"

//add by liangh 设备日志
#define VasLogCommand		"VasLog"

// 设备状态查询结构体，以链表形式保存
//////////////////////////////////////////////////////////////////////////
typedef struct tagVasCenterRequstDeviceInfo
{
	char szIP[64];
}VasCenterRequestDeviceInfo;

typedef struct tagDeviceSingleStatus
{
	char szKey[64];
	char szValue[128];

	tagDeviceSingleStatus()
	{
		szKey[0] = 0;
		szValue[0] = 0;
	}
}DeviceSingleStatus;

typedef struct tagDeviceStatusItem
{
	DeviceSingleStatus status;
	tagDeviceStatusItem *pNext;		// 用于创建单向链表

	tagDeviceStatusItem()
	{
		pNext = NULL;
	}
}DeviceStatusItem;

typedef struct tagDeviceStatusChain
{
	int nCount;		// 项数量
	char szHscDeviceIp[64];
	DeviceStatusItem *pHeadStatus;		// 属性单链表头
	tagDeviceStatusChain *pNextHsc;		// 下一个HSC设备节点

	tagDeviceStatusChain()
	{
		nCount = 0;
		szHscDeviceIp[0] = 0;
		pHeadStatus = NULL;
		pNextHsc = NULL;
	}
}DeviceStatusChain;
*/
//#endif