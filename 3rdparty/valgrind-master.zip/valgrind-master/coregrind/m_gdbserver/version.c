#include "server.h"
const char version[] = "gdbserver protocol box extracted from gdb 6.6";
