#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <assert.h>
#include <signal.h>

#include "libwebsockets.h"


#include <syslog.h>
#include <sys/time.h>
#include <unistd.h>


static volatile int force_exit = 0;
static int versa, state;
static int times = -1;

#define MAX_ECHO_PAYLOAD 1024

struct per_session_data__echo {
	size_t rx, tx;
	unsigned char buf[LWS_PRE + MAX_ECHO_PAYLOAD];
	unsigned int len;
	unsigned int index;
	int final;
	int continuation;
	int binary;
};

static int
callback_echo(struct lws *wsi, enum lws_callback_reasons reason, void *user,
	      void *in, size_t len)
{
	struct per_session_data__echo *pss =
			(struct per_session_data__echo *)user;
	int n;

	switch (reason)
	{
	case LWS_CALLBACK_CLOSED:
	case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
		lwsl_notice("closed\n");
		state = 0;
		break;

	case LWS_CALLBACK_CLIENT_ESTABLISHED:
		lwsl_notice("Client has connected\n");
		pss->index = 0;
		pss->len = -1;
		state = 2;
		break;

	case LWS_CALLBACK_CLIENT_RECEIVE:
		lwsl_notice("Client RX: %s", (char *)in);
		break;

	case LWS_CALLBACK_CLIENT_WRITEABLE:
		/* we will send our packet... */
		pss->len = sprintf((char *)&pss->buf[LWS_PRE],
				   "hello from libwebsockets-test-echo client pid %d index %d\n",
				   getpid(), pss->index++);
		lwsl_notice("Client TX: %s", &pss->buf[LWS_PRE]);
		n = lws_write(wsi, &pss->buf[LWS_PRE], pss->len, LWS_WRITE_TEXT);
		if (n < 0) {
			lwsl_err("ERROR %d writing to socket, hanging up\n", n);
			return -1;
		}
		if (n < (int)pss->len) {
			lwsl_err("Partial write\n");
			return -1;
		}
		break;
	case LWS_CALLBACK_CLIENT_CONFIRM_EXTENSION_SUPPORTED:
		/* reject everything else except permessage-deflate */
		if (strcmp(in, "permessage-deflate"))
			return 1;
		break;

	default:
		break;
	}

	return 0;
}



static struct lws_protocols protocols[] = {
	/* first protocol must always be HTTP handler */

	{
		"my_echo_protocol",
		callback_echo,
		sizeof(struct per_session_data__echo),	/* per_session_data_size */
		MAX_ECHO_PAYLOAD,
	},
	{
		NULL, NULL, 0		/* End of list */
	}
};

static const struct lws_extension exts[] = {
	{
		"permessage-deflate",
		lws_extension_callback_pm_deflate,
		"permessage-deflate; client_no_context_takeover; client_max_window_bits"
	},
	{
		"deflate-frame",
		lws_extension_callback_pm_deflate,
		"deflate_frame"
	},
	{ NULL, NULL, NULL /* terminator */ }
};


void sighandler(int sig)
{
	force_exit = 1;
}


int main(int argc, char **argv)
{
	int n = 0;
	int port = 8081;
	int use_ssl = 0;
	struct lws_context *context;
	int opts = 0;
	char interface_name[128] = "";
	const char *_interface = NULL;


/* LOG_PERROR is not POSIX standard, and may not be portable */

	int syslog_options = LOG_PID | LOG_PERROR;
	int client = 0;
	int listen_port = 80;
	struct lws_context_creation_info info;
	char passphrase[256];
	char uri[256] = "/";
	char address[256], ads_port[256 + 30];
	int rate_us = 250000;
	unsigned long long oldus;
	struct lws *wsi;
	int disallow_selfsigned = 0;
	struct timeval tv;
	const char *connect_protocol = NULL;
	struct lws_client_connect_info i;

	int debug_level = 511;
	int daemonize = 0;

	memset(&info, 0, sizeof info);
	lwsl_notice("Built to support client operations\n");

	/* we will only try to log things according to our debug_level */
	setlogmask(LOG_UPTO (LOG_DEBUG));
	openlog("lwsts", syslog_options, LOG_DAEMON);


	/* tell the library what debug level to emit and to send it to syslog */
	lws_set_log_level(debug_level, lwsl_emit_syslog);

	lwsl_notice("libwebsockets test server echo - license LGPL2.1+SLE\n");
	lwsl_notice("(C) Copyright 2010-2016 Andy Green <andy@warmcat.com>\n");


	lwsl_notice("Running in client mode\n");

	lwsl_debug("log test **** \n");
	listen_port = CONTEXT_PORT_NO_LISTEN;
//	if (use_ssl && !disallow_selfsigned)
//	{
//		lwsl_info("allowing selfsigned\n");
//		use_ssl = 2;
//	}
//	else
//	{
//		lwsl_info("requiring server cert validation against %s\n",
//			  ssl_cert);
//		info.ssl_ca_filepath = ssl_cert;
//	}


	info.port = listen_port;
	info.iface = _interface;
	info.protocols = protocols;
	info.ssl_cert_filepath = NULL;
	info.ssl_private_key_filepath = NULL;

	info.gid = -1;
	info.uid = -1;
	info.extensions = exts;
	info.options = opts | LWS_SERVER_OPTION_VALIDATE_UTF8;

	if (use_ssl)
		info.options |= LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;
#ifndef LWS_NO_EXTENSIONS
	info.extensions = exts;
#endif

	context = lws_create_context(&info);
	if (context == NULL) {
		lwsl_err("libwebsocket init failed\n");
		return -1;
	}

	signal(SIGINT, sighandler);

	strcpy(address,"192.168.9.56");
	lwsl_notice("Client connecting to %s:%u....\n",address, port);
	address[sizeof(address) - 1] = '\0';
	sprintf(ads_port, "%s:%u", address, port & 65535);

	memset(&i, 0, sizeof(i));

	i.context = context;
	i.address = address;
	i.port = port;
	i.ssl_connection = use_ssl;
	i.path = uri;
	i.host = ads_port;
	i.origin = ads_port;
	i.protocol = connect_protocol;

	wsi = lws_client_connect_via_info(&i);
	if (!wsi) {
		lwsl_err("Client failed to connect to %s:%u\n",
			 address, port);
		goto bail;
	}

	gettimeofday(&tv, NULL);
	oldus = ((unsigned long long)tv.tv_sec * 1000000) + tv.tv_usec;
	while(!force_exit)
	{
		lws_service(context, 50);

		gettimeofday(&tv, NULL);
		if( ((unsigned long long)tv.tv_sec * 1000000) + tv.tv_usec - oldus > 400000 )
		{
//			lws_callback_on_writable_all_protocol(context,&protocols[0]);
			oldus = ((unsigned long long)tv.tv_sec * 1000000) + tv.tv_usec;
		}
	}

#if 0
	n = 0;
	while (n >= 0 && !force_exit) {

		if (client && !state && times) {
			state = 1;
			lwsl_notice("Client connecting to %s:%u....\n",
				    address, port);
			/* we are in client mode */

			address[sizeof(address) - 1] = '\0';
			sprintf(ads_port, "%s:%u", address, port & 65535);
			if (times > 0)
				times--;

			memset(&i, 0, sizeof(i));

			i.context = context;
			i.address = address;
			i.port = port;
			i.ssl_connection = use_ssl;
			i.path = uri;
			i.host = ads_port;
			i.origin = ads_port;
			i.protocol = connect_protocol;

			wsi = lws_client_connect_via_info(&i);
			if (!wsi) {
				lwsl_err("Client failed to connect to %s:%u\n",
					 address, port);
				goto bail;
			}
		}

		if (client && !versa && times) {
			gettimeofday(&tv, NULL);

			if (((((unsigned long long)tv.tv_sec * 1000000) + tv.tv_usec) - oldus) > rate_us) {
				lws_callback_on_writable_all_protocol(context,
						&protocols[0]);
				oldus = ((unsigned long long)tv.tv_sec * 1000000) + tv.tv_usec;
				if (times > 0)
					times--;
			}
		}

		if (client && !state && !times)
			break;

		n = lws_service(context, 10);
	}

#endif
	bail:
	lws_context_destroy(context);

	lwsl_notice("libwebsockets-test-echo exited cleanly\n");
	closelog();

	return 0;
}
